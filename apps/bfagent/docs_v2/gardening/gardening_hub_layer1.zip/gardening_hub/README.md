# Gardening Hub - Layer 1 Foundation

Expertensystem für Gartengestaltung mit CAD-Integration.

## Übersicht

Layer 1 implementiert die Grundlagen des Gardening Hub Systems:

- **Datenbank-getriebene Architektur**: Alle Kategorien, Regeln und Konfigurationen in der Datenbank
- **Keine hardcoded Enums**: Maximale Flexibilität ohne Code-Deployment
- **Async SQLAlchemy 2.0+**: Moderne async/await Patterns
- **Type Hints**: Durchgängige Typisierung für bessere IDE-Unterstützung

## Projektstruktur

```
gardening_hub/
├── __init__.py              # Package Export
├── models/                  # SQLAlchemy Models
│   ├── base.py              # Base, TimestampMixin
│   ├── lookups.py           # 6 Lookup-Tabellen
│   ├── pflanze.py           # Pflanzenart, Standortanforderung
│   ├── cad.py               # CAD Layer, Symbole, Attribute
│   └── regeln.py            # Regelkategorien, Expertenregeln
├── schemas/                 # Pydantic Schemas
│   ├── lookups.py           # Lookup-Schemas
│   └── pflanze.py           # CRUD-Schemas für Pflanzen
├── repositories/            # Data Access Layer
│   ├── base.py              # Generic Repository
│   ├── lookup_repository.py
│   ├── pflanzen_repository.py
│   ├── cad_repository.py
│   └── regel_repository.py
├── services/                # Business Logic
│   ├── pflanzen_service.py  # Pflanzen-Operationen
│   └── regel_engine.py      # Expertenregel-Auswertung
├── unit_of_work/            # Transaktionsmanagement
│   └── uow.py
├── alembic/versions/        # Migrations
│   ├── 001_gh_lookup_tabellen.py
│   ├── 002_gh_kern_tabellen.py
│   ├── 003_gh_cad_konfiguration.py
│   └── 004_gh_expertenregeln.py
└── seed/                    # Seed-Daten
    ├── 001a_lkp_licht_winterhaerte.sql
    ├── 001b_lkp_boden_lebensform.sql
    ├── 001c_lkp_verwendung_farben.sql
    ├── 002_pflanzenarten.sql
    ├── 003_cad_konfiguration.sql
    └── 004_expertenregeln.sql
```

## Datenbank-Schema

### Lookup-Tabellen (6)
| Tabelle | Beschreibung | Einträge |
|---------|--------------|----------|
| `gh_lkp_lichtbedarf` | Lichtbedarf-Stufen | 4 |
| `gh_lkp_winterhaertezonen` | USDA Zonen 5-8 | 8 |
| `gh_lkp_bodenarten` | Bodentypen | 7 |
| `gh_lkp_lebensformen` | Wuchstypen | 11 |
| `gh_lkp_verwendungen` | Einsatzbereiche | 13 |
| `gh_lkp_bluetefarben` | Blütenfarben | 12 |

### Kern-Tabellen (2)
- `gh_pflanzenarten`: Pflanzen-Stammdaten
- `gh_standortanforderungen`: Standort-Anforderungen (1:1)

### CAD-Tabellen (3)
- `gh_cad_layer`: DXF-Layer-Definitionen
- `gh_cad_symbole`: Block-Definitionen
- `gh_cad_attribute`: Attribut-Definitionen

### Regel-Tabellen (2)
- `gh_regel_kategorien`: Regelkategorien
- `gh_expertenregeln`: Expertenregeln (JSON-basiert)

## Installation

```bash
# Dependencies
pip install sqlalchemy[asyncio] asyncpg pydantic alembic

# Migrations ausführen
alembic upgrade head

# Seed-Daten laden
psql -d gardening_hub -f seed/001a_lkp_licht_winterhaerte.sql
psql -d gardening_hub -f seed/001b_lkp_boden_lebensform.sql
psql -d gardening_hub -f seed/001c_lkp_verwendung_farben.sql
psql -d gardening_hub -f seed/002_pflanzenarten.sql
psql -d gardening_hub -f seed/003_cad_konfiguration.sql
psql -d gardening_hub -f seed/004_expertenregeln.sql
```

## Verwendung

```python
from sqlalchemy.ext.asyncio import create_async_engine
from gardening_hub import (
    UnitOfWork, 
    create_unit_of_work_factory,
    PflanzenService,
    RegelEngine,
    StandortKontext,
)

# Setup
engine = create_async_engine("postgresql+asyncpg://user:pass@localhost/gardening_hub")
session_factory = create_unit_of_work_factory(engine)

# Pflanzen suchen
async with UnitOfWork(session_factory) as uow:
    service = PflanzenService(uow)
    
    # Alle bienenfreundlichen Pflanzen
    pflanzen = await service.get_bienenfreundliche_pflanzen()
    
    # Suche nach Name
    ergebnis = await service.suche_pflanzen("Lavendel")

# Expertenregeln anwenden
async with UnitOfWork(session_factory) as uow:
    engine = RegelEngine(uow)
    
    standort = StandortKontext(
        licht_code="VOLLE_SONNE",
        winterhaerte_zone_code="ZONE_7A",
        ist_trocken=True
    )
    
    pflanzen = await uow.pflanzen.get_alle_mit_standort()
    bewertungen = await engine.bewerte_pflanzen(standort, pflanzen)
    
    for b in bewertungen:
        if b.empfohlen:
            print(f"✓ {b.pflanze.deutscher_name}: Score {b.gesamt_score}")
        else:
            print(f"✗ {b.pflanze.deutscher_name}: {b.ausschluss_grund}")
```

## Layer 2 (geplant)

- Junction-Table für Boden (M:N)
- Blütezeit-Tabelle
- Companion Planting Regeln
- CAD-Parser für Gartenplan-Import
- Sonnenstunden-Zonenerkennung

## Architektur-Prinzipien

1. **Datenbank-getrieben**: Neue Kategorien/Regeln per SQL INSERT
2. **Separation of Concerns**: Models → Repositories → Services
3. **Unit of Work Pattern**: Transaktionskontrolle
4. **Async First**: Alle DB-Operationen async

## Lizenz

MIT License
