"""
Gardening Hub - Expertensystem für Gartengestaltung

Layer 1: Foundation

Dieses Paket enthält die Grundlagen für ein datenbank-getriebenes
Expertensystem zur Gartenplanung und Pflanzenauswahl.

Architektur-Prinzipien:
- Datenbank-getrieben: Alle Kategorien und Regeln in DB
- Keine hardcoded Enums für fachliche Werte
- Async SQLAlchemy 2.0+
- Unit of Work Pattern
- Type Hints durchgängig

Module:
- models: SQLAlchemy Models (Lookups, Pflanzen, CAD, Regeln)
- schemas: Pydantic Schemas für Validierung
- repositories: Data Access Layer
- services: Business Logic (Pflanzenservice, Regelengine)
- unit_of_work: Transaktionsmanagement

Verwendung:
    from sqlalchemy.ext.asyncio import create_async_engine
    from gardening_hub.unit_of_work import UnitOfWork, create_unit_of_work_factory
    from gardening_hub.services import PflanzenService, RegelEngine
    
    engine = create_async_engine(DATABASE_URL)
    session_factory = create_unit_of_work_factory(engine)
    
    async with UnitOfWork(session_factory) as uow:
        service = PflanzenService(uow)
        pflanzen = await service.get_alle_pflanzen()
"""

__version__ = "0.1.0"
__author__ = "Gardening Hub Team"

from gardening_hub.models import (
    Base,
    Pflanzenart,
    Standortanforderung,
    LkpLichtbedarf,
    LkpWinterhaertezone,
    LkpBodenart,
    LkpLebensform,
)
from gardening_hub.unit_of_work import UnitOfWork, create_unit_of_work_factory
from gardening_hub.services import PflanzenService, RegelEngine, StandortKontext

__all__ = [
    # Version
    "__version__",
    # Base
    "Base",
    # Models
    "Pflanzenart",
    "Standortanforderung",
    "LkpLichtbedarf",
    "LkpWinterhaertezone",
    "LkpBodenart",
    "LkpLebensform",
    # Unit of Work
    "UnitOfWork",
    "create_unit_of_work_factory",
    # Services
    "PflanzenService",
    "RegelEngine",
    "StandortKontext",
]
