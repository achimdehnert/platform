"""
Gardening Hub: Lookup-Tabellen

Revision ID: gh_001
Revises: None
Create Date: 2025-01-XX

Erstellt alle Lookup-Tabellen für das Gardening Hub System.
Keine hardcoded Enums - alles datenbank-getrieben.
"""
from alembic import op
import sqlalchemy as sa

revision = 'gh_001'
down_revision = None
branch_labels = ('gardening_hub',)
depends_on = None


def create_lookup_columns() -> list:
    """Standard-Spalten für alle Lookup-Tabellen."""
    return [
        sa.Column('code', sa.String(30), primary_key=True),
        sa.Column('name_de', sa.String(100), nullable=False),
        sa.Column('name_en', sa.String(100)),
        sa.Column('beschreibung', sa.Text),
        sa.Column('sortierung', sa.Integer, default=0),
        sa.Column('ist_aktiv', sa.Boolean, default=True),
    ]


def upgrade():
    # === 1. Lichtbedarf ===
    op.create_table(
        'gh_lkp_lichtbedarf',
        *create_lookup_columns(),
        sa.Column('sonnenstunden_min', sa.Numeric(3, 1)),
        sa.Column('sonnenstunden_max', sa.Numeric(3, 1)),
        sa.Column('icon', sa.String(50)),
    )
    
    # === 2. Winterhärtezonen ===
    op.create_table(
        'gh_lkp_winterhaertezonen',
        *create_lookup_columns(),
        sa.Column('temperatur_min_c', sa.Numeric(4, 1), nullable=False),
        sa.Column('temperatur_max_c', sa.Numeric(4, 1), nullable=False),
        sa.Column('de_zone', sa.String(10)),
    )
    
    # === 3. Bodenarten ===
    op.create_table(
        'gh_lkp_bodenarten',
        *create_lookup_columns(),
        sa.Column('drainage', sa.String(30)),
        sa.Column('naehrstoffspeicherung', sa.String(30)),
        sa.Column('bearbeitbarkeit', sa.String(30)),
    )
    
    # === 4. Lebensformen ===
    op.create_table(
        'gh_lkp_lebensformen',
        *create_lookup_columns(),
        sa.Column('ist_gehoelz', sa.Boolean, default=False),
        sa.Column('ist_krautig', sa.Boolean, default=False),
        sa.Column('lebensdauer_jahre_min', sa.Integer),
        sa.Column('lebensdauer_jahre_max', sa.Integer),
    )
    
    # === 5. Verwendungen ===
    op.create_table(
        'gh_lkp_verwendungen',
        *create_lookup_columns(),
        sa.Column('kategorie', sa.String(50)),
    )
    
    # === 6. Blütefarben ===
    op.create_table(
        'gh_lkp_bluetefarben',
        *create_lookup_columns(),
        sa.Column('hex_code', sa.String(7)),
        sa.Column('farbgruppe', sa.String(30)),
    )


def downgrade():
    op.drop_table('gh_lkp_bluetefarben')
    op.drop_table('gh_lkp_verwendungen')
    op.drop_table('gh_lkp_lebensformen')
    op.drop_table('gh_lkp_bodenarten')
    op.drop_table('gh_lkp_winterhaertezonen')
    op.drop_table('gh_lkp_lichtbedarf')
