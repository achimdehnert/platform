"""
Gardening Hub: Kern-Tabellen (Pflanzenarten, Standortanforderungen)

Revision ID: gh_002
Revises: gh_001
Create Date: 2025-01-XX

Erstellt die Haupttabellen für Pflanzenarten und Standortanforderungen.
Alle kategorischen Werte als Fremdschlüssel zu Lookup-Tabellen.
"""
from alembic import op
import sqlalchemy as sa

revision = 'gh_002'
down_revision = 'gh_001'
branch_labels = None
depends_on = None


def upgrade():
    # === Pflanzenarten ===
    op.create_table(
        'gh_pflanzenarten',
        # Primärschlüssel
        sa.Column('id', sa.Integer, primary_key=True),
        
        # Zeitstempel
        sa.Column('created_at', sa.DateTime, nullable=False, 
                  server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, nullable=False, 
                  server_default=sa.func.now(), onupdate=sa.func.now()),
        
        # Nomenklatur
        sa.Column('botanischer_name', sa.String(200), unique=True, nullable=False),
        sa.Column('deutscher_name', sa.String(200), nullable=False),
        sa.Column('weitere_namen', sa.Text),
        
        # Taxonomie
        sa.Column('familie', sa.String(100)),
        sa.Column('familie_deutsch', sa.String(100)),
        sa.Column('gattung', sa.String(100)),
        
        # Lebensform (FK)
        sa.Column('lebensform_code', sa.String(30), 
                  sa.ForeignKey('gh_lkp_lebensformen.code'), nullable=False),
        
        # Wuchseigenschaften
        sa.Column('hoehe_min_cm', sa.Integer),
        sa.Column('hoehe_max_cm', sa.Integer),
        sa.Column('breite_min_cm', sa.Integer),
        sa.Column('breite_max_cm', sa.Integer),
        
        # Eigenschaften (Booleans)
        sa.Column('ist_heimisch', sa.Boolean, default=False),
        sa.Column('ist_essbar', sa.Boolean, default=False),
        sa.Column('ist_heilpflanze', sa.Boolean, default=False),
        sa.Column('ist_giftig', sa.Boolean, default=False),
        sa.Column('ist_bienenfreundlich', sa.Boolean, default=False),
        sa.Column('ist_immergruen', sa.Boolean, default=False),
        sa.Column('ist_duftend', sa.Boolean, default=False),
        
        # Zusatzinfo
        sa.Column('beschreibung', sa.Text),
        sa.Column('pflegehinweise', sa.Text),
    )
    
    # Indizes für häufige Suchen
    op.create_index('ix_gh_pflanzen_botanischer_name', 
                    'gh_pflanzenarten', ['botanischer_name'])
    op.create_index('ix_gh_pflanzen_deutscher_name', 
                    'gh_pflanzenarten', ['deutscher_name'])
    op.create_index('ix_gh_pflanzen_lebensform', 
                    'gh_pflanzenarten', ['lebensform_code'])
    op.create_index('ix_gh_pflanzen_familie', 
                    'gh_pflanzenarten', ['familie'])
    
    # === Standortanforderungen ===
    op.create_table(
        'gh_standortanforderungen',
        # Primärschlüssel
        sa.Column('id', sa.Integer, primary_key=True),
        
        # Fremdschlüssel zur Pflanze (1:1)
        sa.Column('pflanzenart_id', sa.Integer,
                  sa.ForeignKey('gh_pflanzenarten.id', ondelete='CASCADE'),
                  unique=True, nullable=False),
        
        # Lichtbedarf (FK)
        sa.Column('licht_optimal_code', sa.String(30),
                  sa.ForeignKey('gh_lkp_lichtbedarf.code'), nullable=False),
        sa.Column('licht_min_code', sa.String(30),
                  sa.ForeignKey('gh_lkp_lichtbedarf.code')),
        sa.Column('licht_max_code', sa.String(30),
                  sa.ForeignKey('gh_lkp_lichtbedarf.code')),
        
        # Winterhärte (FK)
        sa.Column('winterhaerte_zone_code', sa.String(30),
                  sa.ForeignKey('gh_lkp_winterhaertezonen.code'), nullable=False),
        
        # Boden (Codes komma-separiert, M:N in Layer 2)
        sa.Column('boden_typen_codes', sa.String(200)),
        
        # pH-Wert
        sa.Column('ph_min', sa.Numeric(3, 1)),
        sa.Column('ph_max', sa.Numeric(3, 1)),
        
        # Feuchtigkeit
        sa.Column('trockenheitsvertraeglich', sa.Boolean, default=False),
        sa.Column('staunaesse_vertraeglich', sa.Boolean, default=False),
    )
    
    # Indizes für Standort-Suche
    op.create_index('ix_gh_standort_licht', 
                    'gh_standortanforderungen', ['licht_optimal_code'])
    op.create_index('ix_gh_standort_winterhaerte', 
                    'gh_standortanforderungen', ['winterhaerte_zone_code'])


def downgrade():
    op.drop_index('ix_gh_standort_winterhaerte')
    op.drop_index('ix_gh_standort_licht')
    op.drop_table('gh_standortanforderungen')
    
    op.drop_index('ix_gh_pflanzen_familie')
    op.drop_index('ix_gh_pflanzen_lebensform')
    op.drop_index('ix_gh_pflanzen_deutscher_name')
    op.drop_index('ix_gh_pflanzen_botanischer_name')
    op.drop_table('gh_pflanzenarten')
