"""
Gardening Hub: CAD-Konfiguration

Revision ID: gh_003
Revises: gh_002
Create Date: 2025-01-XX

CAD-Layer und Symbole als Datenbank-Konfiguration.
Ermöglicht flexible Anpassung ohne Code-Deployment.
"""
from alembic import op
import sqlalchemy as sa

revision = 'gh_003'
down_revision = 'gh_002'
branch_labels = None
depends_on = None


def upgrade():
    # === CAD Layer-Definition ===
    op.create_table(
        'gh_cad_layer',
        sa.Column('code', sa.String(30), primary_key=True),
        sa.Column('name_de', sa.String(100), nullable=False),
        sa.Column('dxf_layer_name', sa.String(50), nullable=False),
        sa.Column('farbe_aci', sa.Integer),  # AutoCAD Color Index
        sa.Column('linientyp', sa.String(30), default='CONTINUOUS'),
        sa.Column('linienstaerke', sa.Numeric(4, 2)),  # mm
        sa.Column('beschreibung', sa.Text),
        sa.Column('sortierung', sa.Integer, default=0),
        sa.Column('ist_aktiv', sa.Boolean, default=True),
    )
    
    # === CAD Symbol-Definition ===
    op.create_table(
        'gh_cad_symbole',
        sa.Column('code', sa.String(30), primary_key=True),
        sa.Column('name_de', sa.String(100), nullable=False),
        sa.Column('block_name', sa.String(50), nullable=False),
        sa.Column('kategorie', sa.String(30)),  # pflanze, struktur, ausstattung
        sa.Column('breite_cm', sa.Numeric(6, 2)),
        sa.Column('hoehe_cm', sa.Numeric(6, 2)),
        sa.Column('layer_code', sa.String(30), sa.ForeignKey('gh_cad_layer.code')),
        sa.Column('beschreibung', sa.Text),
        sa.Column('ist_aktiv', sa.Boolean, default=True),
    )
    
    # Index für Kategorie-Suche
    op.create_index('ix_gh_cad_symbole_kategorie', 
                    'gh_cad_symbole', ['kategorie'])
    
    # === CAD Attribute für Symbole ===
    op.create_table(
        'gh_cad_attribute',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('symbol_code', sa.String(30), 
                  sa.ForeignKey('gh_cad_symbole.code'), nullable=False),
        sa.Column('tag', sa.String(30), nullable=False),  # DXF ATTRIB tag
        sa.Column('name_de', sa.String(100), nullable=False),
        sa.Column('datentyp', sa.String(20)),  # text, zahl, datum
        sa.Column('pflichtfeld', sa.Boolean, default=False),
        sa.Column('standardwert', sa.String(100)),
        sa.Column('sortierung', sa.Integer, default=0),
    )
    
    # Index für Symbol-Lookup
    op.create_index('ix_gh_cad_attribute_symbol', 
                    'gh_cad_attribute', ['symbol_code'])


def downgrade():
    op.drop_index('ix_gh_cad_attribute_symbol')
    op.drop_table('gh_cad_attribute')
    op.drop_index('ix_gh_cad_symbole_kategorie')
    op.drop_table('gh_cad_symbole')
    op.drop_table('gh_cad_layer')
