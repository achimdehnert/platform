"""
Gardening Hub: Expertenregeln

Revision ID: gh_004
Revises: gh_003
Create Date: 2025-01-XX

Datenbank-getriebene Expertenregeln für Pflanzempfehlungen.
Regeln können per SQL hinzugefügt werden ohne Code-Deployment.
"""
from alembic import op
import sqlalchemy as sa

revision = 'gh_004'
down_revision = 'gh_003'
branch_labels = None
depends_on = None


def upgrade():
    # === Regelkategorien ===
    op.create_table(
        'gh_regel_kategorien',
        sa.Column('code', sa.String(30), primary_key=True),
        sa.Column('name_de', sa.String(100), nullable=False),
        sa.Column('beschreibung', sa.Text),
        sa.Column('prioritaet', sa.Integer, default=100),
        sa.Column('ist_aktiv', sa.Boolean, default=True),
    )
    
    # === Expertenregeln ===
    op.create_table(
        'gh_expertenregeln',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('code', sa.String(50), unique=True, nullable=False),
        sa.Column('kategorie_code', sa.String(30), 
                  sa.ForeignKey('gh_regel_kategorien.code'), nullable=False),
        sa.Column('name_de', sa.String(200), nullable=False),
        sa.Column('beschreibung', sa.Text),
        
        # Regel-Definition (JSON für Flexibilität)
        sa.Column('bedingung_json', sa.Text, nullable=False),
        sa.Column('aktion', sa.String(30), nullable=False),  # empfehlen, warnen, ausschliessen
        sa.Column('meldung_template', sa.Text),
        
        # Gewichtung
        sa.Column('gewicht', sa.Integer, default=100),
        sa.Column('ist_aktiv', sa.Boolean, default=True),
    )
    
    # Indizes
    op.create_index('ix_gh_regeln_kategorie', 
                    'gh_expertenregeln', ['kategorie_code'])
    op.create_index('ix_gh_regeln_aktion', 
                    'gh_expertenregeln', ['aktion'])


def downgrade():
    op.drop_index('ix_gh_regeln_aktion')
    op.drop_index('ix_gh_regeln_kategorie')
    op.drop_table('gh_expertenregeln')
    op.drop_table('gh_regel_kategorien')
