"""
Gardening Hub - Models Package.

Exportiert alle SQLAlchemy Models für einfachen Import.
"""
from .base import Base, TimestampMixin
from .lookups import (
    BaseLookup,
    LkpLichtbedarf,
    LkpWinterhaertezone,
    LkpBodenart,
    LkpLebensform,
    LkpVerwendung,
    LkpBluetefarbe,
)
from .pflanze import Pflanzenart, Standortanforderung
from .cad import CadLayer, CadSymbol, CadAttribut
from .regeln import RegelKategorie, Expertenregel

__all__ = [
    # Base
    "Base",
    "TimestampMixin",
    # Lookups
    "BaseLookup",
    "LkpLichtbedarf",
    "LkpWinterhaertezone",
    "LkpBodenart",
    "LkpLebensform",
    "LkpVerwendung",
    "LkpBluetefarbe",
    # Kern
    "Pflanzenart",
    "Standortanforderung",
    # CAD
    "CadLayer",
    "CadSymbol",
    "CadAttribut",
    # Regeln
    "RegelKategorie",
    "Expertenregel",
]
