"""
Gardening Hub - Basis-Klassen für alle Models.

Folgt dem etablierten Pattern aus dem BF Agent Framework.
Async SQLAlchemy 2.0+ mit Type Hints.
"""
from __future__ import annotations
from datetime import datetime
from sqlalchemy import Column, DateTime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Deklarative Basis für alle Models."""
    pass


class TimestampMixin:
    """
    Automatische Zeitstempel für alle Entitäten.
    
    Verwendung:
        class MeinModel(Base, TimestampMixin):
            ...
    """
    created_at: Mapped[datetime] = mapped_column(
        DateTime, 
        default=datetime.utcnow, 
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, 
        default=datetime.utcnow, 
        onupdate=datetime.utcnow, 
        nullable=False
    )
