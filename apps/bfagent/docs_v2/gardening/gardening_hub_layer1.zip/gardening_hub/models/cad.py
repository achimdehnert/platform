"""
Gardening Hub - CAD-Konfiguration Models.

Datenbank-getriebene Layer- und Symbol-Definitionen.
Ermöglicht flexible Anpassung der CAD-Ausgabe ohne Code-Änderung.
"""
from __future__ import annotations
from sqlalchemy import String, Integer, Numeric, Boolean, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base


class CadLayer(Base):
    """
    CAD-Layer Definition.
    
    Definiert DXF-Layer mit Farben, Linientypen und Linienstärken.
    Ermöglicht konsistente CAD-Ausgaben nach definierten Standards.
    """
    __tablename__ = 'gh_cad_layer'
    
    code: Mapped[str] = mapped_column(String(30), primary_key=True)
    name_de: Mapped[str] = mapped_column(String(100), nullable=False)
    dxf_layer_name: Mapped[str] = mapped_column(String(50), nullable=False)
    farbe_aci: Mapped[int | None] = mapped_column(Integer)  # AutoCAD Color Index
    linientyp: Mapped[str] = mapped_column(String(30), default='CONTINUOUS')
    linienstaerke: Mapped[float | None] = mapped_column(Numeric(4, 2))  # mm
    beschreibung: Mapped[str | None] = mapped_column(Text)
    sortierung: Mapped[int] = mapped_column(Integer, default=0)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    symbole: Mapped[list[CadSymbol]] = relationship(back_populates="layer")
    
    def __repr__(self) -> str:
        return f"<CadLayer(code='{self.code}', dxf='{self.dxf_layer_name}')>"


class CadSymbol(Base):
    """
    CAD-Symbol (Block) Definition.
    
    Definiert wiederverwendbare Blöcke für Pflanzen,
    Strukturelemente und Ausstattung.
    """
    __tablename__ = 'gh_cad_symbole'
    
    code: Mapped[str] = mapped_column(String(30), primary_key=True)
    name_de: Mapped[str] = mapped_column(String(100), nullable=False)
    block_name: Mapped[str] = mapped_column(String(50), nullable=False)
    kategorie: Mapped[str | None] = mapped_column(String(30))  # pflanze, struktur, ausstattung
    breite_cm: Mapped[float | None] = mapped_column(Numeric(6, 2))
    hoehe_cm: Mapped[float | None] = mapped_column(Numeric(6, 2))
    layer_code: Mapped[str | None] = mapped_column(
        String(30), ForeignKey('gh_cad_layer.code')
    )
    beschreibung: Mapped[str | None] = mapped_column(Text)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    layer: Mapped[CadLayer | None] = relationship(back_populates="symbole")
    attribute: Mapped[list[CadAttribut]] = relationship(
        back_populates="symbol",
        order_by="CadAttribut.sortierung"
    )
    
    def __repr__(self) -> str:
        return f"<CadSymbol(code='{self.code}', block='{self.block_name}')>"


class CadAttribut(Base):
    """
    CAD-Attribut Definition für Blöcke.
    
    Definiert die Attribute (ATTRIB/ATTDEF), die ein Block
    enthalten kann. Ermöglicht dynamische Pflanzendaten in CAD.
    """
    __tablename__ = 'gh_cad_attribute'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    symbol_code: Mapped[str] = mapped_column(
        String(30), ForeignKey('gh_cad_symbole.code'), nullable=False
    )
    tag: Mapped[str] = mapped_column(String(30), nullable=False)  # DXF ATTRIB tag
    name_de: Mapped[str] = mapped_column(String(100), nullable=False)
    datentyp: Mapped[str | None] = mapped_column(String(20))  # text, zahl, datum
    pflichtfeld: Mapped[bool] = mapped_column(Boolean, default=False)
    standardwert: Mapped[str | None] = mapped_column(String(100))
    sortierung: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    symbol: Mapped[CadSymbol] = relationship(back_populates="attribute")
    
    def __repr__(self) -> str:
        return f"<CadAttribut(tag='{self.tag}', symbol='{self.symbol_code}')>"
