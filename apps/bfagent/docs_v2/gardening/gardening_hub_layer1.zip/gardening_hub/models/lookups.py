"""
Gardening Hub - Lookup-Tabellen.

ALLE kategorischen Werte kommen aus der Datenbank.
Keine hardcoded Enums - maximale Flexibilität durch DB-Konfiguration.
"""
from __future__ import annotations
from sqlalchemy import String, Integer, Numeric, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base


class BaseLookup(Base):
    """
    Abstrakte Basisklasse für alle Lookup-Tabellen.
    
    Standard-Schema:
    - code: Technischer Schlüssel (PRIMARY KEY)
    - name_de: Deutsche Bezeichnung
    - name_en: Englische Bezeichnung (optional)
    - beschreibung: Erklärungstext
    - sortierung: Für UI-Reihenfolge
    - ist_aktiv: Soft-Delete / Deaktivierung
    """
    __abstract__ = True
    
    code: Mapped[str] = mapped_column(String(30), primary_key=True)
    name_de: Mapped[str] = mapped_column(String(100), nullable=False)
    name_en: Mapped[str | None] = mapped_column(String(100))
    beschreibung: Mapped[str | None] = mapped_column(Text)
    sortierung: Mapped[int] = mapped_column(Integer, default=0)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, default=True)


class LkpLichtbedarf(BaseLookup):
    """
    Lichtbedarf-Stufen.
    
    Beispiele:
    - VOLLE_SONNE: >6 Stunden direkte Sonne
    - TEILSONNE: 4-6 Stunden
    - HALBSCHATTEN: 2-4 Stunden
    - SCHATTEN: <2 Stunden
    """
    __tablename__ = 'gh_lkp_lichtbedarf'
    
    sonnenstunden_min: Mapped[float | None] = mapped_column(Numeric(3, 1))
    sonnenstunden_max: Mapped[float | None] = mapped_column(Numeric(3, 1))
    icon: Mapped[str | None] = mapped_column(String(50))


class LkpWinterhaertezone(BaseLookup):
    """
    USDA Winterhärtezonen.
    
    Internationale Standardklassifikation für Frostverträglichkeit.
    Deutschland: hauptsächlich Zone 6-8.
    """
    __tablename__ = 'gh_lkp_winterhaertezonen'
    
    temperatur_min_c: Mapped[float] = mapped_column(Numeric(4, 1), nullable=False)
    temperatur_max_c: Mapped[float] = mapped_column(Numeric(4, 1), nullable=False)
    de_zone: Mapped[str | None] = mapped_column(String(10))


class LkpBodenart(BaseLookup):
    """
    Bodenarten für Standortanforderungen.
    
    Klassifikation nach Drainage, Nährstoffspeicherung
    und Bearbeitbarkeit.
    """
    __tablename__ = 'gh_lkp_bodenarten'
    
    drainage: Mapped[str | None] = mapped_column(String(30))
    naehrstoffspeicherung: Mapped[str | None] = mapped_column(String(30))
    bearbeitbarkeit: Mapped[str | None] = mapped_column(String(30))


class LkpLebensform(BaseLookup):
    """
    Lebensform/Wuchstyp der Pflanze.
    
    NICHT als Python Enum - kommt aus der Datenbank!
    Ermöglicht Erweiterung ohne Code-Deployment.
    """
    __tablename__ = 'gh_lkp_lebensformen'
    
    ist_gehoelz: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_krautig: Mapped[bool] = mapped_column(Boolean, default=False)
    lebensdauer_jahre_min: Mapped[int | None] = mapped_column(Integer)
    lebensdauer_jahre_max: Mapped[int | None] = mapped_column(Integer)


class LkpVerwendung(BaseLookup):
    """
    Verwendungszweck im Garten.
    
    Kategorien: pflanzung, struktur, gefaess, wasser, spezial, nutzung, oekologie
    """
    __tablename__ = 'gh_lkp_verwendungen'
    
    kategorie: Mapped[str | None] = mapped_column(String(50))


class LkpBluetefarbe(BaseLookup):
    """
    Blütenfarben für Filterung und Gestaltung.
    
    Mit Hex-Code für visuelle Darstellung und
    Farbgruppe für Farbharmonie-Berechnung.
    """
    __tablename__ = 'gh_lkp_bluetefarben'
    
    hex_code: Mapped[str | None] = mapped_column(String(7))  # z.B. #FF5733
    farbgruppe: Mapped[str | None] = mapped_column(String(30))  # warm, kalt, neutral
