"""
Gardening Hub - Kern-Entitäten: Pflanzenart und Standortanforderung.

Alle kategorischen Werte als Fremdschlüssel zu Lookup-Tabellen.
Keine hardcoded Enums im Code.
"""
from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import String, Integer, ForeignKey, Text, Boolean, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, TimestampMixin

if TYPE_CHECKING:
    from .lookups import LkpLebensform, LkpLichtbedarf, LkpWinterhaertezone


class Pflanzenart(Base, TimestampMixin):
    """
    Pflanzenart - Kernentität des Gardening Hub.
    
    Speichert botanische und praktische Informationen
    zu einer Pflanzenart. Standortanforderungen werden
    in separater Tabelle (1:1) gespeichert.
    
    Alle kategorischen Felder sind Fremdschlüssel zu Lookup-Tabellen.
    """
    __tablename__ = 'gh_pflanzenarten'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    
    # === Nomenklatur ===
    botanischer_name: Mapped[str] = mapped_column(
        String(200), unique=True, nullable=False, index=True
    )
    deutscher_name: Mapped[str] = mapped_column(
        String(200), nullable=False, index=True
    )
    weitere_namen: Mapped[str | None] = mapped_column(Text)
    
    # === Taxonomie ===
    familie: Mapped[str | None] = mapped_column(String(100))
    familie_deutsch: Mapped[str | None] = mapped_column(String(100))
    gattung: Mapped[str | None] = mapped_column(String(100))
    
    # === Lebensform (FK zu Lookup) ===
    lebensform_code: Mapped[str] = mapped_column(
        String(30),
        ForeignKey('gh_lkp_lebensformen.code'),
        nullable=False,
        index=True
    )
    
    # === Wuchseigenschaften ===
    hoehe_min_cm: Mapped[int | None] = mapped_column(Integer)
    hoehe_max_cm: Mapped[int | None] = mapped_column(Integer)
    breite_min_cm: Mapped[int | None] = mapped_column(Integer)
    breite_max_cm: Mapped[int | None] = mapped_column(Integer)
    
    # === Eigenschaften (Booleans - binäre Merkmale, keine Kategorien) ===
    ist_heimisch: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_essbar: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_heilpflanze: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_giftig: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_bienenfreundlich: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_immergruen: Mapped[bool] = mapped_column(Boolean, default=False)
    ist_duftend: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # === Zusatzinfo ===
    beschreibung: Mapped[str | None] = mapped_column(Text)
    pflegehinweise: Mapped[str | None] = mapped_column(Text)
    
    # === Relationships ===
    lebensform: Mapped[LkpLebensform] = relationship(
        "LkpLebensform",
        lazy="joined"
    )
    standort: Mapped[Standortanforderung | None] = relationship(
        "Standortanforderung",
        back_populates="pflanze",
        uselist=False,
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<Pflanzenart(id={self.id}, name='{self.deutscher_name}')>"
    
    @property
    def hoehe_anzeige(self) -> str:
        """Formatierte Höhenangabe für Anzeige."""
        if self.hoehe_min_cm and self.hoehe_max_cm:
            return f"{self.hoehe_min_cm}-{self.hoehe_max_cm} cm"
        elif self.hoehe_max_cm:
            return f"bis {self.hoehe_max_cm} cm"
        return "k.A."
    
    @property
    def breite_anzeige(self) -> str:
        """Formatierte Breitenangabe für Anzeige."""
        if self.breite_min_cm and self.breite_max_cm:
            return f"{self.breite_min_cm}-{self.breite_max_cm} cm"
        elif self.breite_max_cm:
            return f"bis {self.breite_max_cm} cm"
        return "k.A."


class Standortanforderung(Base):
    """
    Standortanforderungen einer Pflanzenart.
    
    1:1 Beziehung zu Pflanzenart.
    Alle Kategorien als Fremdschlüssel zu Lookup-Tabellen.
    """
    __tablename__ = 'gh_standortanforderungen'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pflanzenart_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey('gh_pflanzenarten.id', ondelete='CASCADE'),
        unique=True,
        nullable=False
    )
    
    # === Lichtbedarf (FK zu Lookup) ===
    licht_optimal_code: Mapped[str] = mapped_column(
        String(30),
        ForeignKey('gh_lkp_lichtbedarf.code'),
        nullable=False,
        index=True
    )
    licht_min_code: Mapped[str | None] = mapped_column(
        String(30),
        ForeignKey('gh_lkp_lichtbedarf.code')
    )
    licht_max_code: Mapped[str | None] = mapped_column(
        String(30),
        ForeignKey('gh_lkp_lichtbedarf.code')
    )
    
    # === Winterhärte (FK zu Lookup) ===
    winterhaerte_zone_code: Mapped[str] = mapped_column(
        String(30),
        ForeignKey('gh_lkp_winterhaertezonen.code'),
        nullable=False,
        index=True
    )
    
    # === Boden ===
    # Komma-separierte Codes aus gh_lkp_bodenarten
    # In Layer 2: Junction-Table für echte M:N Beziehung
    boden_typen_codes: Mapped[str | None] = mapped_column(String(200))
    
    # === pH-Wert ===
    ph_min: Mapped[float | None] = mapped_column(Numeric(3, 1))
    ph_max: Mapped[float | None] = mapped_column(Numeric(3, 1))
    
    # === Feuchtigkeit (Booleans - binäre Eigenschaften) ===
    trockenheitsvertraeglich: Mapped[bool] = mapped_column(Boolean, default=False)
    staunaesse_vertraeglich: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # === Relationships ===
    pflanze: Mapped[Pflanzenart] = relationship(
        "Pflanzenart",
        back_populates="standort"
    )
    licht_optimal: Mapped[LkpLichtbedarf] = relationship(
        "LkpLichtbedarf",
        foreign_keys=[licht_optimal_code],
        lazy="joined"
    )
    winterhaerte_zone: Mapped[LkpWinterhaertezone] = relationship(
        "LkpWinterhaertezone",
        foreign_keys=[winterhaerte_zone_code],
        lazy="joined"
    )
    
    def __repr__(self) -> str:
        return f"<Standortanforderung(pflanzenart_id={self.pflanzenart_id})>"
    
    @property
    def boden_liste(self) -> list[str]:
        """Bodentypen als Liste."""
        if self.boden_typen_codes:
            return [code.strip() for code in self.boden_typen_codes.split(',')]
        return []
    
    @property
    def ph_bereich_anzeige(self) -> str:
        """Formatierter pH-Bereich für Anzeige."""
        if self.ph_min and self.ph_max:
            return f"pH {self.ph_min}-{self.ph_max}"
        elif self.ph_min:
            return f"pH ab {self.ph_min}"
        elif self.ph_max:
            return f"pH bis {self.ph_max}"
        return "k.A."
