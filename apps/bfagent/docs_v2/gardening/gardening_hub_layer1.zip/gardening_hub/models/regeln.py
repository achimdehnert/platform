"""
Gardening Hub - Expertenregel-Models.

Datenbank-getriebene Regeln für das Expertensystem.
Ermöglicht flexible Regeldefinition ohne Code-Deployment.
"""
from __future__ import annotations
from sqlalchemy import String, Integer, Boolean, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base


class RegelKategorie(Base):
    """
    Kategorie für Expertenregeln.
    
    Gruppiert Regeln nach Themen wie Licht, Winterhärte, Boden, etc.
    Priorität bestimmt die Auswertungsreihenfolge.
    """
    __tablename__ = 'gh_regel_kategorien'
    
    code: Mapped[str] = mapped_column(String(30), primary_key=True)
    name_de: Mapped[str] = mapped_column(String(100), nullable=False)
    beschreibung: Mapped[str | None] = mapped_column(Text)
    prioritaet: Mapped[int] = mapped_column(Integer, default=100)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    regeln: Mapped[list[Expertenregel]] = relationship(
        back_populates="kategorie",
        order_by="Expertenregel.gewicht.desc()"
    )
    
    def __repr__(self) -> str:
        return f"<RegelKategorie(code='{self.code}')>"


class Expertenregel(Base):
    """
    Einzelne Expertenregel für Pflanzempfehlungen.
    
    Die Bedingung wird als JSON gespeichert für maximale Flexibilität:
    {
        "standort.licht": {"$eq": "pflanze.licht_optimal_code"},
        "pflanze.ist_giftig": {"$eq": false}
    }
    
    Unterstützte Operatoren:
    - $eq: Gleichheit
    - $lt, $gt, $lte, $gte: Vergleiche
    - $in: Enthält (für Listen)
    - $between: Zwischen zwei Werten
    
    Aktionen:
    - empfehlen: Pflanze wird positiv bewertet
    - warnen: Hinweis wird angezeigt
    - ausschliessen: Pflanze wird nicht empfohlen
    """
    __tablename__ = 'gh_expertenregeln'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    kategorie_code: Mapped[str] = mapped_column(
        String(30), ForeignKey('gh_regel_kategorien.code'), nullable=False
    )
    name_de: Mapped[str] = mapped_column(String(200), nullable=False)
    beschreibung: Mapped[str | None] = mapped_column(Text)
    
    # Regel-Definition
    bedingung_json: Mapped[str] = mapped_column(Text, nullable=False)
    aktion: Mapped[str] = mapped_column(String(30), nullable=False)
    meldung_template: Mapped[str | None] = mapped_column(Text)
    
    # Gewichtung für Scoring
    gewicht: Mapped[int] = mapped_column(Integer, default=100)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    kategorie: Mapped[RegelKategorie] = relationship(back_populates="regeln")
    
    def __repr__(self) -> str:
        return f"<Expertenregel(code='{self.code}', aktion='{self.aktion}')>"
