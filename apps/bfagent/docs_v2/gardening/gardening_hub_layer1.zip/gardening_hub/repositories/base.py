"""
Gardening Hub - Generisches Repository Pattern.

Async SQLAlchemy 2.0+ mit Type Hints.
"""
from __future__ import annotations
from typing import TypeVar, Generic, Sequence, Any
from sqlalchemy import select, func, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from gardening_hub.models.base import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    """
    Generisches Repository für CRUD-Operationen.
    
    Verwendung:
        class PflanzenRepository(BaseRepository[Pflanzenart]):
            def __init__(self, session: AsyncSession):
                super().__init__(Pflanzenart, session)
    """
    
    def __init__(self, model: type[ModelType], session: AsyncSession):
        self._model = model
        self._session = session
    
    async def get_by_id(self, id: int | str) -> ModelType | None:
        """Einzelnen Datensatz per ID/PK laden."""
        return await self._session.get(self._model, id)
    
    async def get_all(
        self,
        *,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[ModelType]:
        """Alle Datensätze mit Pagination."""
        stmt = select(self._model).offset(skip).limit(limit)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def count(self) -> int:
        """Anzahl aller Datensätze."""
        stmt = select(func.count()).select_from(self._model)
        result = await self._session.execute(stmt)
        return result.scalar_one()
    
    async def exists(self, id: int | str) -> bool:
        """Prüft ob Datensatz existiert."""
        obj = await self.get_by_id(id)
        return obj is not None
    
    async def create(self, obj: ModelType) -> ModelType:
        """Neuen Datensatz erstellen."""
        self._session.add(obj)
        await self._session.flush()
        await self._session.refresh(obj)
        return obj
    
    async def create_many(self, objs: list[ModelType]) -> list[ModelType]:
        """Mehrere Datensätze erstellen."""
        self._session.add_all(objs)
        await self._session.flush()
        for obj in objs:
            await self._session.refresh(obj)
        return objs
    
    async def update(self, obj: ModelType) -> ModelType:
        """Datensatz aktualisieren."""
        await self._session.flush()
        await self._session.refresh(obj)
        return obj
    
    async def delete(self, obj: ModelType) -> None:
        """Datensatz löschen."""
        await self._session.delete(obj)
        await self._session.flush()
    
    async def delete_by_id(self, id: int | str) -> bool:
        """Datensatz per ID löschen."""
        obj = await self.get_by_id(id)
        if obj:
            await self.delete(obj)
            return True
        return False
