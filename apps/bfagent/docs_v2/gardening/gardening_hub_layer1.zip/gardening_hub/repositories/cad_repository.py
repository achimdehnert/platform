"""
Gardening Hub - Repository für CAD-Konfiguration.

Zugriff auf Layer, Symbole und Attribute für CAD-Operationen.
"""
from __future__ import annotations
from typing import Sequence
from sqlalchemy import select
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from gardening_hub.models.cad import CadLayer, CadSymbol, CadAttribut


class CadRepository:
    """
    Repository für CAD-Konfiguration.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            layer = await uow.cad.get_layer_alle()
    """
    
    def __init__(self, session: AsyncSession):
        self._session = session
    
    # =========================================================================
    # LAYER
    # =========================================================================
    
    async def get_layer_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[CadLayer]:
        """Alle CAD-Layer laden."""
        stmt = select(CadLayer).order_by(CadLayer.sortierung)
        if nur_aktive:
            stmt = stmt.where(CadLayer.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_layer_by_code(self, code: str) -> CadLayer | None:
        """Einzelnen Layer per Code laden."""
        return await self._session.get(CadLayer, code)
    
    async def get_layer_by_dxf_name(self, dxf_name: str) -> CadLayer | None:
        """Layer per DXF-Layername finden."""
        stmt = (
            select(CadLayer)
            .where(CadLayer.dxf_layer_name == dxf_name)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    # =========================================================================
    # SYMBOLE
    # =========================================================================
    
    async def get_symbole_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[CadSymbol]:
        """Alle CAD-Symbole laden."""
        stmt = (
            select(CadSymbol)
            .options(joinedload(CadSymbol.layer))
        )
        if nur_aktive:
            stmt = stmt.where(CadSymbol.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_symbol_by_code(self, code: str) -> CadSymbol | None:
        """Einzelnes Symbol per Code laden."""
        stmt = (
            select(CadSymbol)
            .options(
                joinedload(CadSymbol.layer),
                joinedload(CadSymbol.attribute),
            )
            .where(CadSymbol.code == code)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def get_symbol_by_block_name(self, block_name: str) -> CadSymbol | None:
        """Symbol per DXF-Blockname finden."""
        stmt = (
            select(CadSymbol)
            .options(
                joinedload(CadSymbol.layer),
                joinedload(CadSymbol.attribute),
            )
            .where(CadSymbol.block_name == block_name)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def get_symbole_by_kategorie(
        self, 
        kategorie: str
    ) -> Sequence[CadSymbol]:
        """Symbole nach Kategorie filtern."""
        stmt = (
            select(CadSymbol)
            .options(joinedload(CadSymbol.layer))
            .where(CadSymbol.kategorie == kategorie)
            .where(CadSymbol.ist_aktiv == True)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_pflanzensymbole(self) -> Sequence[CadSymbol]:
        """Alle Pflanzensymbole laden."""
        return await self.get_symbole_by_kategorie('pflanze')
    
    # =========================================================================
    # ATTRIBUTE
    # =========================================================================
    
    async def get_attribute_fuer_symbol(
        self, 
        symbol_code: str
    ) -> Sequence[CadAttribut]:
        """Alle Attribute für ein Symbol laden."""
        stmt = (
            select(CadAttribut)
            .where(CadAttribut.symbol_code == symbol_code)
            .order_by(CadAttribut.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_pflichtattribute_fuer_symbol(
        self, 
        symbol_code: str
    ) -> Sequence[CadAttribut]:
        """Nur Pflichtattribute für ein Symbol laden."""
        stmt = (
            select(CadAttribut)
            .where(CadAttribut.symbol_code == symbol_code)
            .where(CadAttribut.pflichtfeld == True)
            .order_by(CadAttribut.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
