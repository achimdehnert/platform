"""
Gardening Hub - Repository für Lookup-Tabellen.

Bietet typisierte Zugriffsmethoden für alle Lookups.
"""
from __future__ import annotations
from typing import Sequence
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from gardening_hub.models.lookups import (
    LkpLichtbedarf,
    LkpWinterhaertezone,
    LkpBodenart,
    LkpLebensform,
    LkpVerwendung,
    LkpBluetefarbe,
)


class LookupRepository:
    """
    Repository für alle Lookup-Tabellen.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            lichtbedarf = await uow.lookups.get_lichtbedarf_alle()
    """
    
    def __init__(self, session: AsyncSession):
        self._session = session
    
    # =========================================================================
    # LICHTBEDARF
    # =========================================================================
    
    async def get_lichtbedarf_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpLichtbedarf]:
        """Alle Lichtbedarf-Stufen laden."""
        stmt = select(LkpLichtbedarf).order_by(LkpLichtbedarf.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpLichtbedarf.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_lichtbedarf_by_code(self, code: str) -> LkpLichtbedarf | None:
        """Einzelnen Lichtbedarf per Code laden."""
        return await self._session.get(LkpLichtbedarf, code)
    
    # =========================================================================
    # WINTERHÄRTEZONEN
    # =========================================================================
    
    async def get_winterhaertezonen_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpWinterhaertezone]:
        """Alle Winterhärtezonen laden."""
        stmt = select(LkpWinterhaertezone).order_by(LkpWinterhaertezone.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpWinterhaertezone.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_winterhaertezone_by_code(
        self, 
        code: str
    ) -> LkpWinterhaertezone | None:
        """Einzelne Winterhärtezone per Code laden."""
        return await self._session.get(LkpWinterhaertezone, code)
    
    async def get_winterhaertezonen_fuer_temperatur(
        self, 
        min_temperatur: float
    ) -> Sequence[LkpWinterhaertezone]:
        """Zonen finden, die eine Mindesttemperatur aushalten."""
        stmt = (
            select(LkpWinterhaertezone)
            .where(LkpWinterhaertezone.temperatur_min_c <= min_temperatur)
            .where(LkpWinterhaertezone.ist_aktiv == True)
            .order_by(LkpWinterhaertezone.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # BODENARTEN
    # =========================================================================
    
    async def get_bodenarten_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpBodenart]:
        """Alle Bodenarten laden."""
        stmt = select(LkpBodenart).order_by(LkpBodenart.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpBodenart.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_bodenart_by_code(self, code: str) -> LkpBodenart | None:
        """Einzelne Bodenart per Code laden."""
        return await self._session.get(LkpBodenart, code)
    
    async def get_bodenarten_by_drainage(
        self, 
        drainage: str
    ) -> Sequence[LkpBodenart]:
        """Bodenarten nach Drainage-Eigenschaft filtern."""
        stmt = (
            select(LkpBodenart)
            .where(LkpBodenart.drainage == drainage)
            .where(LkpBodenart.ist_aktiv == True)
            .order_by(LkpBodenart.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # LEBENSFORMEN
    # =========================================================================
    
    async def get_lebensformen_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpLebensform]:
        """Alle Lebensformen laden."""
        stmt = select(LkpLebensform).order_by(LkpLebensform.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpLebensform.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_lebensform_by_code(self, code: str) -> LkpLebensform | None:
        """Einzelne Lebensform per Code laden."""
        return await self._session.get(LkpLebensform, code)
    
    async def get_lebensformen_gehoelze(self) -> Sequence[LkpLebensform]:
        """Nur Gehölz-Lebensformen laden."""
        stmt = (
            select(LkpLebensform)
            .where(LkpLebensform.ist_gehoelz == True)
            .where(LkpLebensform.ist_aktiv == True)
            .order_by(LkpLebensform.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_lebensformen_krautig(self) -> Sequence[LkpLebensform]:
        """Nur krautige Lebensformen laden."""
        stmt = (
            select(LkpLebensform)
            .where(LkpLebensform.ist_krautig == True)
            .where(LkpLebensform.ist_aktiv == True)
            .order_by(LkpLebensform.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # VERWENDUNGEN
    # =========================================================================
    
    async def get_verwendungen_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpVerwendung]:
        """Alle Verwendungen laden."""
        stmt = select(LkpVerwendung).order_by(LkpVerwendung.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpVerwendung.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_verwendung_by_code(self, code: str) -> LkpVerwendung | None:
        """Einzelne Verwendung per Code laden."""
        return await self._session.get(LkpVerwendung, code)
    
    async def get_verwendungen_by_kategorie(
        self, 
        kategorie: str
    ) -> Sequence[LkpVerwendung]:
        """Verwendungen nach Kategorie filtern."""
        stmt = (
            select(LkpVerwendung)
            .where(LkpVerwendung.kategorie == kategorie)
            .where(LkpVerwendung.ist_aktiv == True)
            .order_by(LkpVerwendung.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # BLÜTEFARBEN
    # =========================================================================
    
    async def get_bluetefarben_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[LkpBluetefarbe]:
        """Alle Blütefarben laden."""
        stmt = select(LkpBluetefarbe).order_by(LkpBluetefarbe.sortierung)
        if nur_aktive:
            stmt = stmt.where(LkpBluetefarbe.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_bluetefarbe_by_code(self, code: str) -> LkpBluetefarbe | None:
        """Einzelne Blütefarbe per Code laden."""
        return await self._session.get(LkpBluetefarbe, code)
    
    async def get_bluetefarben_by_farbgruppe(
        self, 
        farbgruppe: str
    ) -> Sequence[LkpBluetefarbe]:
        """Blütefarben nach Farbgruppe filtern."""
        stmt = (
            select(LkpBluetefarbe)
            .where(LkpBluetefarbe.farbgruppe == farbgruppe)
            .where(LkpBluetefarbe.ist_aktiv == True)
            .order_by(LkpBluetefarbe.sortierung)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
