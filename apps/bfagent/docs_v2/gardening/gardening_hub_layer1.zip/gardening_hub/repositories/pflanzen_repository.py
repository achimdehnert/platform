"""
Gardening Hub - Repository für Pflanzenarten.

Spezifische Abfragen für Pflanzendaten mit Standortfilterung.
"""
from __future__ import annotations
from typing import Sequence
from sqlalchemy import select, or_
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from gardening_hub.models.pflanze import Pflanzenart, Standortanforderung
from gardening_hub.repositories.base import BaseRepository


class PflanzenRepository(BaseRepository[Pflanzenart]):
    """
    Repository für Pflanzenarten mit spezifischen Abfragen.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            pflanze = await uow.pflanzen.get_by_id_mit_standort(1)
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(Pflanzenart, session)
    
    # =========================================================================
    # EINZELABFRAGEN
    # =========================================================================
    
    async def get_by_id_mit_standort(self, id: int) -> Pflanzenart | None:
        """Pflanze mit allen Standortdaten laden."""
        stmt = (
            select(Pflanzenart)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
            .where(Pflanzenart.id == id)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def get_by_botanischer_name(self, name: str) -> Pflanzenart | None:
        """Pflanze per botanischem Namen finden."""
        stmt = (
            select(Pflanzenart)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
            .where(Pflanzenart.botanischer_name == name)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    # =========================================================================
    # SUCHE
    # =========================================================================
    
    async def suche_nach_name(
        self, 
        suchbegriff: str,
        limit: int = 20
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach deutschem oder botanischem Namen suchen."""
        pattern = f"%{suchbegriff}%"
        stmt = (
            select(Pflanzenart)
            .options(joinedload(Pflanzenart.lebensform))
            .where(
                or_(
                    Pflanzenart.deutscher_name.ilike(pattern),
                    Pflanzenart.botanischer_name.ilike(pattern),
                    Pflanzenart.weitere_namen.ilike(pattern),
                )
            )
            .order_by(Pflanzenart.deutscher_name)
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # FILTER NACH EIGENSCHAFTEN
    # =========================================================================
    
    async def get_by_lebensform(
        self, 
        lebensform_code: str
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach Lebensform filtern."""
        stmt = (
            select(Pflanzenart)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
            .where(Pflanzenart.lebensform_code == lebensform_code)
            .order_by(Pflanzenart.deutscher_name)
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_by_eigenschaften(
        self,
        ist_bienenfreundlich: bool | None = None,
        ist_heimisch: bool | None = None,
        ist_immergruen: bool | None = None,
        ist_giftig: bool | None = None,
        ist_essbar: bool | None = None,
        ist_duftend: bool | None = None,
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach booleschen Eigenschaften filtern."""
        stmt = (
            select(Pflanzenart)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
        )
        
        if ist_bienenfreundlich is not None:
            stmt = stmt.where(
                Pflanzenart.ist_bienenfreundlich == ist_bienenfreundlich
            )
        if ist_heimisch is not None:
            stmt = stmt.where(Pflanzenart.ist_heimisch == ist_heimisch)
        if ist_immergruen is not None:
            stmt = stmt.where(Pflanzenart.ist_immergruen == ist_immergruen)
        if ist_giftig is not None:
            stmt = stmt.where(Pflanzenart.ist_giftig == ist_giftig)
        if ist_essbar is not None:
            stmt = stmt.where(Pflanzenart.ist_essbar == ist_essbar)
        if ist_duftend is not None:
            stmt = stmt.where(Pflanzenart.ist_duftend == ist_duftend)
        
        stmt = stmt.order_by(Pflanzenart.deutscher_name)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_by_hoehe(
        self,
        max_hoehe_cm: int | None = None,
        min_hoehe_cm: int | None = None,
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach Höhe filtern."""
        stmt = (
            select(Pflanzenart)
            .options(joinedload(Pflanzenart.lebensform))
        )
        
        if max_hoehe_cm is not None:
            stmt = stmt.where(Pflanzenart.hoehe_max_cm <= max_hoehe_cm)
        if min_hoehe_cm is not None:
            stmt = stmt.where(Pflanzenart.hoehe_min_cm >= min_hoehe_cm)
        
        stmt = stmt.order_by(Pflanzenart.hoehe_max_cm)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    # =========================================================================
    # FILTER NACH STANDORT
    # =========================================================================
    
    async def get_by_standort(
        self,
        licht_code: str | None = None,
        winterhaerte_zone_code: str | None = None,
        trockenheitsvertraeglich: bool | None = None,
        staunaesse_vertraeglich: bool | None = None,
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach Standortanforderungen filtern."""
        stmt = (
            select(Pflanzenart)
            .join(Pflanzenart.standort)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
        )
        
        if licht_code is not None:
            # Pflanze passt wenn licht_code zwischen min und max liegt
            # oder optimal entspricht
            stmt = stmt.where(
                or_(
                    Standortanforderung.licht_optimal_code == licht_code,
                    Standortanforderung.licht_min_code == licht_code,
                    Standortanforderung.licht_max_code == licht_code,
                )
            )
        
        if winterhaerte_zone_code is not None:
            stmt = stmt.where(
                Standortanforderung.winterhaerte_zone_code == winterhaerte_zone_code
            )
        
        if trockenheitsvertraeglich is not None:
            stmt = stmt.where(
                Standortanforderung.trockenheitsvertraeglich == trockenheitsvertraeglich
            )
        
        if staunaesse_vertraeglich is not None:
            stmt = stmt.where(
                Standortanforderung.staunaesse_vertraeglich == staunaesse_vertraeglich
            )
        
        stmt = stmt.order_by(Pflanzenart.deutscher_name)
        result = await self._session.execute(stmt)
        return result.unique().scalars().all()
    
    async def get_fuer_sonnigen_standort(self) -> Sequence[Pflanzenart]:
        """Pflanzen für sonnige Standorte laden."""
        return await self.get_by_standort(licht_code='VOLLE_SONNE')
    
    async def get_fuer_schattigen_standort(self) -> Sequence[Pflanzenart]:
        """Pflanzen für schattige Standorte laden."""
        return await self.get_by_standort(licht_code='SCHATTEN')
    
    async def get_trockenheitsvertraeglich(self) -> Sequence[Pflanzenart]:
        """Trockenheitsverträgliche Pflanzen laden."""
        return await self.get_by_standort(trockenheitsvertraeglich=True)
    
    # =========================================================================
    # MIT STANDORT LADEN
    # =========================================================================
    
    async def get_alle_mit_standort(
        self,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Pflanzenart]:
        """Alle Pflanzen mit Standortdaten laden."""
        stmt = (
            select(Pflanzenart)
            .options(
                joinedload(Pflanzenart.standort),
                joinedload(Pflanzenart.lebensform),
            )
            .offset(skip)
            .limit(limit)
            .order_by(Pflanzenart.deutscher_name)
        )
        result = await self._session.execute(stmt)
        return result.unique().scalars().all()
