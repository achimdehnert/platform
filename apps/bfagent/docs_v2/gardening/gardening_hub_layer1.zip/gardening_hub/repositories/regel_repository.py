"""
Gardening Hub - Repository für Expertenregeln.

Zugriff auf Regelkategorien und Regeln für das Expertensystem.
"""
from __future__ import annotations
from typing import Sequence
from sqlalchemy import select
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from gardening_hub.models.regeln import RegelKategorie, Expertenregel


class RegelRepository:
    """
    Repository für Expertenregeln.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            regeln = await uow.regeln.get_alle_aktiven()
    """
    
    def __init__(self, session: AsyncSession):
        self._session = session
    
    # =========================================================================
    # KATEGORIEN
    # =========================================================================
    
    async def get_kategorien_alle(
        self, 
        nur_aktive: bool = True
    ) -> Sequence[RegelKategorie]:
        """Alle Regelkategorien laden."""
        stmt = select(RegelKategorie).order_by(RegelKategorie.prioritaet.desc())
        if nur_aktive:
            stmt = stmt.where(RegelKategorie.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_kategorie_by_code(self, code: str) -> RegelKategorie | None:
        """Einzelne Kategorie per Code laden."""
        return await self._session.get(RegelKategorie, code)
    
    # =========================================================================
    # REGELN
    # =========================================================================
    
    async def get_alle_aktiven(self) -> Sequence[Expertenregel]:
        """Alle aktiven Regeln laden, sortiert nach Kategorie-Priorität und Gewicht."""
        stmt = (
            select(Expertenregel)
            .join(Expertenregel.kategorie)
            .options(joinedload(Expertenregel.kategorie))
            .where(Expertenregel.ist_aktiv == True)
            .where(RegelKategorie.ist_aktiv == True)
            .order_by(
                RegelKategorie.prioritaet.desc(),
                Expertenregel.gewicht.desc()
            )
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_by_code(self, code: str) -> Expertenregel | None:
        """Einzelne Regel per Code laden."""
        stmt = (
            select(Expertenregel)
            .options(joinedload(Expertenregel.kategorie))
            .where(Expertenregel.code == code)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def get_by_kategorie(
        self, 
        kategorie_code: str,
        nur_aktive: bool = True
    ) -> Sequence[Expertenregel]:
        """Regeln einer Kategorie laden."""
        stmt = (
            select(Expertenregel)
            .options(joinedload(Expertenregel.kategorie))
            .where(Expertenregel.kategorie_code == kategorie_code)
            .order_by(Expertenregel.gewicht.desc())
        )
        if nur_aktive:
            stmt = stmt.where(Expertenregel.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_by_aktion(
        self, 
        aktion: str,
        nur_aktive: bool = True
    ) -> Sequence[Expertenregel]:
        """Regeln nach Aktionstyp laden (empfehlen, warnen, ausschliessen)."""
        stmt = (
            select(Expertenregel)
            .options(joinedload(Expertenregel.kategorie))
            .where(Expertenregel.aktion == aktion)
            .order_by(Expertenregel.gewicht.desc())
        )
        if nur_aktive:
            stmt = stmt.where(Expertenregel.ist_aktiv == True)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def get_licht_regeln(self) -> Sequence[Expertenregel]:
        """Alle Licht-Regeln laden."""
        return await self.get_by_kategorie('LICHT')
    
    async def get_winterhaerte_regeln(self) -> Sequence[Expertenregel]:
        """Alle Winterhärte-Regeln laden."""
        return await self.get_by_kategorie('WINTERHAERTE')
    
    async def get_boden_regeln(self) -> Sequence[Expertenregel]:
        """Alle Boden-Regeln laden."""
        return await self.get_by_kategorie('BODEN')
