"""
Gardening Hub - Schemas Package.

Exportiert alle Pydantic Schemas für einfachen Import.
"""
from .lookups import (
    LookupBase,
    LichtbedarfSchema,
    WinterhaertezoneSchema,
    BodenartSchema,
    LebensformSchema,
    VerwendungSchema,
    BluetefarbeSchema,
)
from .pflanze import (
    StandortanforderungBase,
    StandortanforderungCreate,
    StandortanforderungRead,
    PflanzenartBase,
    PflanzenartCreate,
    PflanzenartRead,
    PflanzenartUpdate,
    PflanzenartListItem,
)

__all__ = [
    # Lookups
    "LookupBase",
    "LichtbedarfSchema",
    "WinterhaertezoneSchema",
    "BodenartSchema",
    "LebensformSchema",
    "VerwendungSchema",
    "BluetefarbeSchema",
    # Pflanzen
    "StandortanforderungBase",
    "StandortanforderungCreate",
    "StandortanforderungRead",
    "PflanzenartBase",
    "PflanzenartCreate",
    "PflanzenartRead",
    "PflanzenartUpdate",
    "PflanzenartListItem",
]
