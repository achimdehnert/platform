"""
Gardening Hub - Pydantic Schemas für Lookup-Tabellen.

Validierung und API-Serialisierung.
"""
from __future__ import annotations
from pydantic import BaseModel, ConfigDict


class LookupBase(BaseModel):
    """Basis-Schema für alle Lookups."""
    model_config = ConfigDict(from_attributes=True)
    
    code: str
    name_de: str
    name_en: str | None = None
    beschreibung: str | None = None
    sortierung: int = 0
    ist_aktiv: bool = True


class LichtbedarfSchema(LookupBase):
    """Schema für Lichtbedarf."""
    sonnenstunden_min: float | None = None
    sonnenstunden_max: float | None = None
    icon: str | None = None


class WinterhaertezoneSchema(LookupBase):
    """Schema für Winterhärtezone."""
    temperatur_min_c: float
    temperatur_max_c: float
    de_zone: str | None = None


class BodenartSchema(LookupBase):
    """Schema für Bodenart."""
    drainage: str | None = None
    naehrstoffspeicherung: str | None = None
    bearbeitbarkeit: str | None = None


class LebensformSchema(LookupBase):
    """Schema für Lebensform."""
    ist_gehoelz: bool = False
    ist_krautig: bool = False
    lebensdauer_jahre_min: int | None = None
    lebensdauer_jahre_max: int | None = None


class VerwendungSchema(LookupBase):
    """Schema für Verwendung."""
    kategorie: str | None = None


class BluetefarbeSchema(LookupBase):
    """Schema für Blütefarbe."""
    hex_code: str | None = None
    farbgruppe: str | None = None
