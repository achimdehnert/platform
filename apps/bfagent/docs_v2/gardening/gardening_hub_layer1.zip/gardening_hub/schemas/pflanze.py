"""
Gardening Hub - Pydantic Schemas für Pflanzenarten.

Validierung für Create/Update Operationen und API-Serialisierung.
"""
from __future__ import annotations
from pydantic import BaseModel, ConfigDict, Field
from .lookups import LichtbedarfSchema, WinterhaertezoneSchema, LebensformSchema


class StandortanforderungBase(BaseModel):
    """Basis-Schema für Standortanforderung."""
    model_config = ConfigDict(from_attributes=True)
    
    licht_optimal_code: str
    licht_min_code: str | None = None
    licht_max_code: str | None = None
    winterhaerte_zone_code: str
    boden_typen_codes: str | None = None
    ph_min: float | None = Field(None, ge=0, le=14)
    ph_max: float | None = Field(None, ge=0, le=14)
    trockenheitsvertraeglich: bool = False
    staunaesse_vertraeglich: bool = False


class StandortanforderungCreate(StandortanforderungBase):
    """Schema zum Erstellen einer Standortanforderung."""
    pass


class StandortanforderungRead(StandortanforderungBase):
    """Schema zum Lesen einer Standortanforderung mit aufgelösten Lookups."""
    id: int
    pflanzenart_id: int
    
    # Aufgelöste Lookups (nur bei Ausgabe)
    licht_optimal: LichtbedarfSchema | None = None
    winterhaerte_zone: WinterhaertezoneSchema | None = None


class PflanzenartBase(BaseModel):
    """Basis-Schema für Pflanzenart."""
    model_config = ConfigDict(from_attributes=True)
    
    botanischer_name: str = Field(..., min_length=3, max_length=200)
    deutscher_name: str = Field(..., min_length=2, max_length=200)
    weitere_namen: str | None = None
    familie: str | None = Field(None, max_length=100)
    familie_deutsch: str | None = Field(None, max_length=100)
    gattung: str | None = Field(None, max_length=100)
    lebensform_code: str
    hoehe_min_cm: int | None = Field(None, ge=0, le=10000)
    hoehe_max_cm: int | None = Field(None, ge=0, le=10000)
    breite_min_cm: int | None = Field(None, ge=0, le=10000)
    breite_max_cm: int | None = Field(None, ge=0, le=10000)
    ist_heimisch: bool = False
    ist_essbar: bool = False
    ist_heilpflanze: bool = False
    ist_giftig: bool = False
    ist_bienenfreundlich: bool = False
    ist_immergruen: bool = False
    ist_duftend: bool = False
    beschreibung: str | None = None
    pflegehinweise: str | None = None


class PflanzenartCreate(PflanzenartBase):
    """Schema zum Erstellen einer Pflanzenart."""
    standort: StandortanforderungCreate | None = None


class PflanzenartRead(PflanzenartBase):
    """Schema zum Lesen einer Pflanzenart mit Relationships."""
    id: int
    lebensform: LebensformSchema | None = None
    standort: StandortanforderungRead | None = None
    
    # Berechnete Properties
    hoehe_anzeige: str | None = None
    breite_anzeige: str | None = None


class PflanzenartUpdate(BaseModel):
    """Schema zum Aktualisieren (alle Felder optional)."""
    model_config = ConfigDict(from_attributes=True)
    
    deutscher_name: str | None = Field(None, min_length=2, max_length=200)
    weitere_namen: str | None = None
    lebensform_code: str | None = None
    hoehe_min_cm: int | None = Field(None, ge=0, le=10000)
    hoehe_max_cm: int | None = Field(None, ge=0, le=10000)
    breite_min_cm: int | None = Field(None, ge=0, le=10000)
    breite_max_cm: int | None = Field(None, ge=0, le=10000)
    ist_heimisch: bool | None = None
    ist_essbar: bool | None = None
    ist_heilpflanze: bool | None = None
    ist_giftig: bool | None = None
    ist_bienenfreundlich: bool | None = None
    ist_immergruen: bool | None = None
    ist_duftend: bool | None = None
    beschreibung: str | None = None
    pflegehinweise: str | None = None


class PflanzenartListItem(BaseModel):
    """Kompaktes Schema für Listendarstellung."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    botanischer_name: str
    deutscher_name: str
    lebensform_code: str
    hoehe_max_cm: int | None = None
    ist_bienenfreundlich: bool = False
    ist_giftig: bool = False
