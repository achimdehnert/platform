-- =============================================================================
-- Gardening Hub: Lookup-Daten Teil 1 - Lichtbedarf & Winterhärte
-- =============================================================================

-- LICHTBEDARF
INSERT INTO gh_lkp_lichtbedarf 
    (code, name_de, name_en, beschreibung, sonnenstunden_min, sonnenstunden_max, sortierung, icon, ist_aktiv) 
VALUES
    ('VOLLE_SONNE', 'Volle Sonne', 'Full Sun', 
     'Mindestens 6 Stunden direkte Sonneneinstrahlung täglich', 
     6.0, 24.0, 1, 'sun', TRUE),
    ('TEILSONNE', 'Teilsonne', 'Partial Sun', 
     '4-6 Stunden direkte Sonne, bevorzugt Morgensonne', 
     4.0, 6.0, 2, 'cloud-sun', TRUE),
    ('HALBSCHATTEN', 'Halbschatten', 'Partial Shade', 
     '2-4 Stunden direkte Sonne oder gefiltertes Licht', 
     2.0, 4.0, 3, 'cloud', TRUE),
    ('SCHATTEN', 'Schatten', 'Full Shade', 
     'Weniger als 2 Stunden direkte Sonne', 
     0.0, 2.0, 4, 'moon', TRUE);

-- WINTERHÄRTEZONEN (USDA, für Deutschland relevant: 5-8)
INSERT INTO gh_lkp_winterhaertezonen 
    (code, name_de, name_en, beschreibung, temperatur_min_c, temperatur_max_c, de_zone, sortierung, ist_aktiv) 
VALUES
    ('ZONE_5A', 'Zone 5a', 'Zone 5a', 
     'Sehr winterhart, Bergregionen', -28.9, -26.1, 'Z5', 1, TRUE),
    ('ZONE_5B', 'Zone 5b', 'Zone 5b', 
     'Sehr winterhart, höhere Lagen', -26.1, -23.3, 'Z5', 2, TRUE),
    ('ZONE_6A', 'Zone 6a', 'Zone 6a', 
     'Winterhart, kontinentales Klima', -23.3, -20.6, 'Z6', 3, TRUE),
    ('ZONE_6B', 'Zone 6b', 'Zone 6b', 
     'Winterhart, Mittelgebirge', -20.6, -17.8, 'Z6', 4, TRUE),
    ('ZONE_7A', 'Zone 7a', 'Zone 7a', 
     'Mäßig winterhart, Norddeutschland', -17.8, -15.0, 'Z7', 5, TRUE),
    ('ZONE_7B', 'Zone 7b', 'Zone 7b', 
     'Mäßig winterhart, Rheinland', -15.0, -12.2, 'Z7', 6, TRUE),
    ('ZONE_8A', 'Zone 8a', 'Zone 8a', 
     'Mild, Weinbauklima', -12.2, -9.4, 'Z8', 7, TRUE),
    ('ZONE_8B', 'Zone 8b', 'Zone 8b', 
     'Mild, Oberrhein/Bodensee', -9.4, -6.7, 'Z8', 8, TRUE);
