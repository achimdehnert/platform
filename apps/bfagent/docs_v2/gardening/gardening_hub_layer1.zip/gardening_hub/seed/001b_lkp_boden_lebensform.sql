-- =============================================================================
-- Gardening Hub: Lookup-Daten Teil 2 - Bodenarten & Lebensformen
-- =============================================================================

-- BODENARTEN
INSERT INTO gh_lkp_bodenarten 
    (code, name_de, name_en, beschreibung, drainage, naehrstoffspeicherung, bearbeitbarkeit, sortierung, ist_aktiv) 
VALUES
    ('SANDIG', 'Sandiger Boden', 'Sandy Soil',
     'Leicht, gut durchlässig, erwärmt schnell, nährstoffarm',
     'sehr_gut', 'gering', 'leicht', 1, TRUE),
    ('LEHMIG', 'Lehmiger Boden', 'Loamy Soil',
     'Ideal: gute Drainage und Nährstoffspeicherung',
     'gut', 'gut', 'mittel', 2, TRUE),
    ('TONIG', 'Toniger Boden', 'Clay Soil',
     'Schwer, speichert Wasser und Nährstoffe, verdichtet leicht',
     'schlecht', 'sehr_gut', 'schwer', 3, TRUE),
    ('HUMOS', 'Humoser Boden', 'Humus-rich Soil',
     'Nährstoffreich, gute Struktur, ideal für die meisten Pflanzen',
     'gut', 'sehr_gut', 'leicht', 4, TRUE),
    ('KALKHALTIG', 'Kalkhaltiger Boden', 'Chalky Soil',
     'Alkalisch, gut durchlässig, für kalkliebende Pflanzen',
     'gut', 'mittel', 'mittel', 5, TRUE),
    ('TORFIG', 'Torfiger Boden', 'Peaty Soil',
     'Sauer, speichert viel Wasser, für Moorbeetpflanzen',
     'schlecht', 'gut', 'leicht', 6, TRUE),
    ('STEINIG', 'Steiniger Boden', 'Rocky Soil',
     'Durchlässig, für Steingartenpflanzen geeignet',
     'sehr_gut', 'gering', 'schwer', 7, TRUE);

-- LEBENSFORMEN
INSERT INTO gh_lkp_lebensformen 
    (code, name_de, name_en, beschreibung, ist_gehoelz, ist_krautig, lebensdauer_jahre_min, lebensdauer_jahre_max, sortierung, ist_aktiv) 
VALUES
    ('EINJAEHRIG', 'Einjährig', 'Annual',
     'Kompletter Lebenszyklus in einer Vegetationsperiode',
     FALSE, TRUE, 0, 1, 1, TRUE),
    ('ZWEIJAEHRIG', 'Zweijährig', 'Biennial',
     'Blüte und Samenbildung im zweiten Jahr',
     FALSE, TRUE, 1, 2, 2, TRUE),
    ('STAUDE', 'Staude', 'Perennial',
     'Mehrjährig, oberirdische Teile sterben im Winter ab',
     FALSE, TRUE, 3, 50, 3, TRUE),
    ('HALBSTRAUCH', 'Halbstrauch', 'Subshrub',
     'Basis verholzt, obere Triebe krautig',
     TRUE, TRUE, 5, 20, 4, TRUE),
    ('STRAUCH', 'Strauch', 'Shrub',
     'Mehrere verholzte Triebe von der Basis',
     TRUE, FALSE, 10, 100, 5, TRUE),
    ('BAUM', 'Baum', 'Tree',
     'Verholzt mit einem Hauptstamm',
     TRUE, FALSE, 20, 500, 6, TRUE),
    ('KLETTERPFLANZE', 'Kletterpflanze', 'Climber',
     'Wächst an Stützen empor, krautig oder verholzend',
     FALSE, TRUE, 1, 50, 7, TRUE),
    ('ZWIEBELPFLANZE', 'Zwiebel-/Knollenpflanze', 'Bulb',
     'Überdauert mit unterirdischen Speicherorganen',
     FALSE, TRUE, 3, 30, 8, TRUE),
    ('ZIERGRAS', 'Ziergras', 'Ornamental Grass',
     'Grasartig, oft horstig wachsend',
     FALSE, TRUE, 3, 30, 9, TRUE),
    ('FARN', 'Farn', 'Fern',
     'Sporenbildend, meist schattenliebend',
     FALSE, TRUE, 5, 50, 10, TRUE),
    ('WASSERPFLANZE', 'Wasserpflanze', 'Aquatic Plant',
     'Lebt im oder am Wasser',
     FALSE, TRUE, 1, 30, 11, TRUE);
