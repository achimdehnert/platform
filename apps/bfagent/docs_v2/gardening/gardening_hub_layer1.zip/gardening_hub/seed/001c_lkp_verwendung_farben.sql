-- =============================================================================
-- Gardening Hub: Lookup-Daten Teil 3 - Verwendungen & Blütefarben
-- =============================================================================

-- VERWENDUNGEN
INSERT INTO gh_lkp_verwendungen 
    (code, name_de, name_en, beschreibung, kategorie, sortierung, ist_aktiv) 
VALUES
    ('BEET', 'Beet', 'Flower Bed',
     'Klassisches Blumen- oder Staudenbeet', 'pflanzung', 1, TRUE),
    ('RABATTE', 'Rabatte', 'Border',
     'Längliche Pflanzstreifen entlang von Wegen oder Mauern', 'pflanzung', 2, TRUE),
    ('STEINGARTEN', 'Steingarten', 'Rock Garden',
     'Bepflanzung zwischen Steinen, meist trocken und sonnig', 'pflanzung', 3, TRUE),
    ('BODENDECKER', 'Bodendecker', 'Ground Cover',
     'Flächige Bepflanzung zur Bodenbedeckung', 'pflanzung', 4, TRUE),
    ('HECKE', 'Hecke', 'Hedge',
     'Lineare Pflanzung als Sichtschutz oder Einfriedung', 'struktur', 5, TRUE),
    ('SOLITAER', 'Solitär', 'Specimen',
     'Einzelstellung als Blickfang', 'struktur', 6, TRUE),
    ('KUEBEL', 'Kübelpflanze', 'Container Plant',
     'Geeignet für Topf- und Kübelkultur', 'gefaess', 7, TRUE),
    ('BALKON', 'Balkonpflanze', 'Balcony Plant',
     'Kompakt, für Balkonkästen geeignet', 'gefaess', 8, TRUE),
    ('TEICHRAND', 'Teichrand', 'Pond Edge',
     'Feuchter Standort am Gewässerrand', 'wasser', 9, TRUE),
    ('DACHBEGRUENUNG', 'Dachbegrünung', 'Green Roof',
     'Für extensive oder intensive Dachbegrünung', 'spezial', 10, TRUE),
    ('SCHNITTBLUME', 'Schnittblume', 'Cut Flower',
     'Geeignet für Blumensträuße', 'nutzung', 11, TRUE),
    ('KUECHENKRAUT', 'Küchenkraut', 'Culinary Herb',
     'Verwendung in der Küche', 'nutzung', 12, TRUE),
    ('BIENENWEIDE', 'Bienenweide', 'Bee Plant',
     'Besonders wertvoll für Bestäuber', 'oekologie', 13, TRUE);

-- BLÜTEFARBEN
INSERT INTO gh_lkp_bluetefarben 
    (code, name_de, name_en, beschreibung, hex_code, farbgruppe, sortierung, ist_aktiv) 
VALUES
    ('WEISS', 'Weiß', 'White', 'Reine weiße Blüten', '#FFFFFF', 'neutral', 1, TRUE),
    ('CREME', 'Creme', 'Cream', 'Cremeweiß bis elfenbein', '#FFFDD0', 'neutral', 2, TRUE),
    ('GELB', 'Gelb', 'Yellow', 'Leuchtend gelb', '#FFD700', 'warm', 3, TRUE),
    ('ORANGE', 'Orange', 'Orange', 'Orange bis apricot', '#FFA500', 'warm', 4, TRUE),
    ('ROT', 'Rot', 'Red', 'Kräftig rot', '#DC143C', 'warm', 5, TRUE),
    ('ROSA', 'Rosa', 'Pink', 'Zartrosa bis pink', '#FF69B4', 'warm', 6, TRUE),
    ('VIOLETT', 'Violett', 'Purple', 'Violett bis lila', '#8B008B', 'kalt', 7, TRUE),
    ('BLAU', 'Blau', 'Blue', 'Blau in allen Schattierungen', '#4169E1', 'kalt', 8, TRUE),
    ('LAVENDEL', 'Lavendel', 'Lavender', 'Zart lila-blau', '#E6E6FA', 'kalt', 9, TRUE),
    ('GRUEN', 'Grün', 'Green', 'Grünliche Blüten', '#228B22', 'neutral', 10, TRUE),
    ('BRAUN', 'Braun', 'Brown', 'Bräunliche bis kupferfarbene Töne', '#8B4513', 'neutral', 11, TRUE),
    ('MEHRFARBIG', 'Mehrfarbig', 'Multicolor', 'Zwei- oder mehrfarbige Blüten', NULL, 'gemischt', 12, TRUE);
