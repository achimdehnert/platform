-- =============================================================================
-- Gardening Hub: Beispielpflanzen (10 typische Gartenpflanzen)
-- =============================================================================

INSERT INTO gh_pflanzenarten (
    id, botanischer_name, deutscher_name, weitere_namen,
    familie, familie_deutsch, gattung, lebensform_code,
    hoehe_min_cm, hoehe_max_cm, breite_min_cm, breite_max_cm,
    ist_heimisch, ist_essbar, ist_heilpflanze, ist_giftig,
    ist_bienenfreundlich, ist_immergruen, ist_duftend,
    beschreibung, pflegehinweise
) VALUES

-- 1. Lavendel
(1, 'Lavandula angustifolia', 'Echter Lavendel', 'Schmalblättriger Lavendel',
 'Lamiaceae', 'Lippenblütler', 'Lavandula', 'HALBSTRAUCH',
 30, 60, 30, 45,
 FALSE, TRUE, TRUE, FALSE,
 TRUE, FALSE, TRUE,
 'Mediterraner Halbstrauch mit silbrigem Laub und intensiv duftenden blauvioletten Blütenähren. Wichtige Bienen- und Schmetterlingsweide.',
 'Im Frühjahr nach der Blüte um ein Drittel zurückschneiden. Nicht ins alte Holz schneiden. Durchlässiger Boden wichtig.'),

-- 2. Sonnenhut
(2, 'Echinacea purpurea', 'Purpur-Sonnenhut', 'Roter Sonnenhut, Igelkopf',
 'Asteraceae', 'Korbblütler', 'Echinacea', 'STAUDE',
 60, 100, 40, 50,
 FALSE, FALSE, TRUE, FALSE,
 TRUE, FALSE, FALSE,
 'Robuste Präriestaude mit großen, purpurrosa Blütenköpfen und markanten kegelförmigen Blütenzentren. Lange Blütezeit von Juli bis September.',
 'Verblühtes regelmäßig entfernen für Nachblüte. Im Frühjahr bodennaher Rückschnitt. Teilung alle 3-4 Jahre.'),

-- 3. Funkie (Hosta)
(3, 'Hosta sieboldiana', 'Blaublatt-Funkie', 'Herzblattlilie, Hosta',
 'Asparagaceae', 'Spargelgewächse', 'Hosta', 'STAUDE',
 40, 80, 60, 100,
 FALSE, FALSE, FALSE, FALSE,
 FALSE, FALSE, FALSE,
 'Schattenstaude mit imposanten blaugrünen, stark strukturierten Blättern. Weiße, leicht duftende Blüten im Hochsommer.',
 'Vor Schneckenfraß schützen. Im Frühjahr mit Kompost mulchen. Regelmäßig wässern bei Trockenheit.'),

-- 4. Beetrose
(4, 'Rosa x hybrida', 'Beetrose', 'Edelrose, Gartenrose',
 'Rosaceae', 'Rosengewächse', 'Rosa', 'STRAUCH',
 60, 120, 40, 60,
 FALSE, FALSE, FALSE, FALSE,
 TRUE, FALSE, TRUE,
 'Klassische Gartenrose mit gefüllten Blüten in vielen Farben. Mehrfachblühend von Juni bis zum Frost.',
 'Frühjahrsschnitt auf 3-5 Augen. Regelmäßig düngen. Auf Sternrußtau und Mehltau achten.'),

-- 5. Buchsbaum
(5, 'Buxus sempervirens', 'Gewöhnlicher Buchsbaum', 'Buchs',
 'Buxaceae', 'Buchsbaumgewächse', 'Buxus', 'STRAUCH',
 50, 400, 50, 200,
 TRUE, FALSE, FALSE, TRUE,
 FALSE, TRUE, FALSE,
 'Immergrünes Formgehölz mit kleinen, glänzenden Blättern. Klassisch für Hecken, Einfassungen und Formschnitt. Achtung: Alle Pflanzenteile giftig!',
 'Formschnitt im Mai/Juni und August. Auf Buchsbaumzünsler kontrollieren. Nicht bei Frost schneiden.'),

-- 6. Fetthenne
(6, 'Sedum telephium', 'Große Fetthenne', 'Purpur-Fetthenne, Waldfetthenne',
 'Crassulaceae', 'Dickblattgewächse', 'Sedum', 'STAUDE',
 30, 60, 30, 40,
 TRUE, FALSE, TRUE, FALSE,
 TRUE, FALSE, FALSE,
 'Anspruchslose Staude mit fleischigen Blättern und flachen rosa-roten Blütendolden. Wichtige Spätblüher-Bienenweide im September.',
 'Sehr pflegeleicht. Stängel erst im Frühjahr abschneiden (Winterschmuck). Verträgt Trockenheit gut.'),

-- 7. Storchschnabel
(7, 'Geranium sanguineum', 'Blut-Storchschnabel', 'Blutrote Geranie',
 'Geraniaceae', 'Storchschnabelgewächse', 'Geranium', 'STAUDE',
 15, 40, 30, 50,
 TRUE, FALSE, FALSE, FALSE,
 TRUE, FALSE, FALSE,
 'Heimische Wildstaude mit magentaroten Blüten und fein geschlitztem Laub. Schöne Herbstfärbung. Robust und langlebig.',
 'Rückschnitt nach der Hauptblüte fördert Nachblüte. Breitet sich langsam aus. Teilung selten nötig.'),

-- 8. Frauenmantel
(8, 'Alchemilla mollis', 'Weicher Frauenmantel', 'Frauenmantel',
 'Rosaceae', 'Rosengewächse', 'Alchemilla', 'STAUDE',
 30, 50, 40, 60,
 FALSE, FALSE, TRUE, FALSE,
 FALSE, FALSE, FALSE,
 'Beliebte Blattschmuckstaude mit samtigen, rundlichen Blättern, die Wassertropfen wie Perlen sammeln. Lockere gelbgrüne Blütenwolken.',
 'Nach der Blüte bodennah zurückschneiden für frischen Austrieb. Sät sich willig aus.'),

-- 9. Waldmeister
(9, 'Galium odoratum', 'Waldmeister', 'Wohlriechendes Labkraut, Maikraut',
 'Rubiaceae', 'Rötegewächse', 'Galium', 'STAUDE',
 15, 30, 30, 50,
 TRUE, TRUE, TRUE, FALSE,
 FALSE, FALSE, TRUE,
 'Heimischer Bodendecker für schattige Standorte. Weiße Sternchenblüten im Mai. Charakteristischer Duft für Maibowle.',
 'Breitet sich über Ausläufer aus. Ideal unter Gehölzen. Ernte vor der Blüte für Maibowle.'),

-- 10. Rispenhortensie
(10, 'Hydrangea paniculata', 'Rispenhortensie', 'Strauchhortensie',
 'Hydrangeaceae', 'Hortensiengewächse', 'Hydrangea', 'STRAUCH',
 150, 300, 150, 250,
 FALSE, FALSE, FALSE, FALSE,
 TRUE, FALSE, FALSE,
 'Großer Blütenstrauch mit kegelförmigen weißen Rispen, die im Herbst rosa verfärben. Robust und winterhart.',
 'Im Frühjahr kräftig zurückschneiden für große Blüten. Regelmäßig wässern. Blüht am einjährigen Holz.');

-- =============================================================================
-- STANDORTANFORDERUNGEN
-- =============================================================================
INSERT INTO gh_standortanforderungen (
    pflanzenart_id, 
    licht_optimal_code, licht_min_code, licht_max_code,
    winterhaerte_zone_code, 
    boden_typen_codes, ph_min, ph_max,
    trockenheitsvertraeglich, staunaesse_vertraeglich
) VALUES
-- 1. Lavendel: Volle Sonne, trocken, kalkliebend
(1, 'VOLLE_SONNE', 'VOLLE_SONNE', 'TEILSONNE',
 'ZONE_6B', 'SANDIG,KALKHALTIG', 6.5, 8.0,
 TRUE, FALSE),

-- 2. Sonnenhut: Sonne bis Halbschatten, anpassungsfähig
(2, 'VOLLE_SONNE', 'TEILSONNE', 'VOLLE_SONNE',
 'ZONE_5A', 'LEHMIG,SANDIG,HUMOS', 6.0, 7.5,
 TRUE, FALSE),

-- 3. Funkie: Schatten, humoser Boden
(3, 'SCHATTEN', 'SCHATTEN', 'HALBSCHATTEN',
 'ZONE_6A', 'HUMOS,LEHMIG', 6.0, 7.5,
 FALSE, FALSE),

-- 4. Beetrose: Volle Sonne, nährstoffreich
(4, 'VOLLE_SONNE', 'TEILSONNE', 'VOLLE_SONNE',
 'ZONE_6B', 'LEHMIG,HUMOS', 6.0, 7.0,
 FALSE, FALSE),

-- 5. Buchsbaum: Flexibel bei Licht, kalkliebend
(5, 'HALBSCHATTEN', 'SCHATTEN', 'VOLLE_SONNE',
 'ZONE_6A', 'LEHMIG,KALKHALTIG,HUMOS', 6.5, 7.5,
 FALSE, FALSE),

-- 6. Fetthenne: Volle Sonne, trocken
(6, 'VOLLE_SONNE', 'VOLLE_SONNE', 'TEILSONNE',
 'ZONE_5A', 'SANDIG,STEINIG,LEHMIG', 6.0, 7.5,
 TRUE, FALSE),

-- 7. Storchschnabel: Sonne bis Halbschatten
(7, 'VOLLE_SONNE', 'TEILSONNE', 'VOLLE_SONNE',
 'ZONE_5A', 'SANDIG,LEHMIG,KALKHALTIG', 5.5, 7.5,
 TRUE, FALSE),

-- 8. Frauenmantel: Halbschatten, anpassungsfähig
(8, 'HALBSCHATTEN', 'HALBSCHATTEN', 'VOLLE_SONNE',
 'ZONE_5A', 'LEHMIG,HUMOS,TONIG', 5.5, 7.5,
 FALSE, FALSE),

-- 9. Waldmeister: Schatten, humos, feucht
(9, 'SCHATTEN', 'SCHATTEN', 'HALBSCHATTEN',
 'ZONE_5A', 'HUMOS,LEHMIG', 5.5, 7.0,
 FALSE, TRUE),

-- 10. Rispenhortensie: Teilsonne, humos
(10, 'TEILSONNE', 'HALBSCHATTEN', 'VOLLE_SONNE',
 'ZONE_5A', 'HUMOS,LEHMIG', 5.5, 7.0,
 FALSE, FALSE);
