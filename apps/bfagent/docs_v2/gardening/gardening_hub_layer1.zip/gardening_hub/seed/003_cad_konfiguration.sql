-- =============================================================================
-- Gardening Hub: CAD Layer und Symbole
-- =============================================================================

-- CAD LAYER
INSERT INTO gh_cad_layer 
    (code, name_de, dxf_layer_name, farbe_aci, linientyp, linienstaerke, beschreibung, sortierung, ist_aktiv)
VALUES
    ('PFLANZEN', 'Pflanzen', 'GH_PFLANZEN', 3, 'CONTINUOUS', 0.25,
     'Hauptlayer für alle Pflanzensymbole', 1, TRUE),
    ('PFLANZEN_BESCHR', 'Pflanzenbeschriftung', 'GH_PFLANZEN_TXT', 7, 'CONTINUOUS', 0.18,
     'Beschriftungen und Labels für Pflanzen', 2, TRUE),
    ('BEETE', 'Beete und Pflanzflächen', 'GH_BEETE', 62, 'CONTINUOUS', 0.35,
     'Beetumrandungen und Pflanzflächen', 3, TRUE),
    ('RASEN', 'Rasenflächen', 'GH_RASEN', 92, 'CONTINUOUS', 0.25,
     'Rasenflächen und Grünflächen', 4, TRUE),
    ('WEGE', 'Wege und Plätze', 'GH_WEGE', 8, 'CONTINUOUS', 0.50,
     'Gartenwege, Terrassen, Plätze', 5, TRUE),
    ('WASSER', 'Wasserflächen', 'GH_WASSER', 150, 'CONTINUOUS', 0.35,
     'Teiche, Bachläufe, Brunnen', 6, TRUE),
    ('BAUWERKE', 'Bauwerke', 'GH_BAUWERKE', 8, 'CONTINUOUS', 0.70,
     'Gebäude, Mauern, Pergolen', 7, TRUE),
    ('EINFRIEDUNG', 'Einfriedung', 'GH_ZAUN', 8, 'DASHED', 0.35,
     'Zäune, Hecken als Einfriedung', 8, TRUE),
    ('MASSLINIEN', 'Maßlinien', 'GH_MASS', 7, 'CONTINUOUS', 0.13,
     'Bemaßungen und Maßketten', 9, TRUE),
    ('SONNEN_ANALYSE', 'Sonnenanalyse', 'GH_SONNE', 2, 'CONTINUOUS', 0.25,
     'Sonnenstunden-Zonen aus Analyse', 10, TRUE);

-- CAD SYMBOLE
INSERT INTO gh_cad_symbole 
    (code, name_de, block_name, kategorie, breite_cm, hoehe_cm, layer_code, beschreibung, ist_aktiv)
VALUES
    -- Pflanzensymbole
    ('PFLANZE_KREIS', 'Pflanze (Kreis)', 'GH_PFLANZE', 'pflanze', 100, 100,
     'PFLANZEN', 'Standard-Pflanzensymbol als Kreis mit Attributen', TRUE),
    ('STAUDE', 'Staude', 'GH_STAUDE', 'pflanze', 50, 50,
     'PFLANZEN', 'Symbol für Stauden', TRUE),
    ('STRAUCH', 'Strauch', 'GH_STRAUCH', 'pflanze', 150, 150,
     'PFLANZEN', 'Symbol für Sträucher', TRUE),
    ('BAUM_KLEIN', 'Kleinbaum', 'GH_BAUM_S', 'pflanze', 300, 300,
     'PFLANZEN', 'Symbol für kleine Bäume (bis 8m)', TRUE),
    ('BAUM_GROSS', 'Großbaum', 'GH_BAUM_L', 'pflanze', 600, 600,
     'PFLANZEN', 'Symbol für große Bäume (über 8m)', TRUE),
    ('HECKE', 'Heckenelement', 'GH_HECKE', 'pflanze', 100, 50,
     'PFLANZEN', 'Heckensymbol (linear)', TRUE),
    -- Struktursymbole
    ('BEETRAND', 'Beetrand', 'GH_BEETRAND', 'struktur', NULL, NULL,
     'BEETE', 'Liniensymbol für Beetumrandung', TRUE),
    ('WEG_BELAG', 'Wegbelag', 'GH_WEG', 'struktur', NULL, NULL,
     'WEGE', 'Flächensymbol für Wege', TRUE),
    -- Ausstattung
    ('BANK', 'Gartenbank', 'GH_BANK', 'ausstattung', 150, 60,
     'BAUWERKE', 'Sitzbank', TRUE),
    ('BRUNNEN', 'Brunnen', 'GH_BRUNNEN', 'ausstattung', 100, 100,
     'WASSER', 'Brunnen oder Wasserspiel', TRUE);

-- CAD ATTRIBUTE (für Pflanzensymbole)
INSERT INTO gh_cad_attribute 
    (symbol_code, tag, name_de, datentyp, pflichtfeld, standardwert, sortierung)
VALUES
    ('PFLANZE_KREIS', 'PFLANZEN_ID', 'Pflanzen-ID', 'zahl', TRUE, NULL, 1),
    ('PFLANZE_KREIS', 'BOT_NAME', 'Botanischer Name', 'text', TRUE, NULL, 2),
    ('PFLANZE_KREIS', 'DE_NAME', 'Deutscher Name', 'text', TRUE, NULL, 3),
    ('PFLANZE_KREIS', 'ANZAHL', 'Stückzahl', 'zahl', FALSE, '1', 4),
    ('PFLANZE_KREIS', 'PFLANZJAHR', 'Pflanzjahr', 'zahl', FALSE, NULL, 5),
    ('PFLANZE_KREIS', 'NOTIZ', 'Notiz', 'text', FALSE, NULL, 6),
    
    ('STAUDE', 'PFLANZEN_ID', 'Pflanzen-ID', 'zahl', TRUE, NULL, 1),
    ('STAUDE', 'DE_NAME', 'Deutscher Name', 'text', TRUE, NULL, 2),
    ('STAUDE', 'ANZAHL', 'Stückzahl', 'zahl', FALSE, '3', 3),
    
    ('STRAUCH', 'PFLANZEN_ID', 'Pflanzen-ID', 'zahl', TRUE, NULL, 1),
    ('STRAUCH', 'DE_NAME', 'Deutscher Name', 'text', TRUE, NULL, 2),
    ('STRAUCH', 'HOEHE_CM', 'Aktuelle Höhe (cm)', 'zahl', FALSE, NULL, 3),
    
    ('BAUM_KLEIN', 'PFLANZEN_ID', 'Pflanzen-ID', 'zahl', TRUE, NULL, 1),
    ('BAUM_KLEIN', 'DE_NAME', 'Deutscher Name', 'text', TRUE, NULL, 2),
    ('BAUM_KLEIN', 'STAMMUMFANG', 'Stammumfang (cm)', 'zahl', FALSE, NULL, 3),
    ('BAUM_KLEIN', 'PFLANZJAHR', 'Pflanzjahr', 'zahl', FALSE, NULL, 4),
    
    ('BAUM_GROSS', 'PFLANZEN_ID', 'Pflanzen-ID', 'zahl', TRUE, NULL, 1),
    ('BAUM_GROSS', 'DE_NAME', 'Deutscher Name', 'text', TRUE, NULL, 2),
    ('BAUM_GROSS', 'STAMMUMFANG', 'Stammumfang (cm)', 'zahl', FALSE, NULL, 3),
    ('BAUM_GROSS', 'KRONENDURCHM', 'Kronendurchmesser (m)', 'zahl', FALSE, NULL, 4);
