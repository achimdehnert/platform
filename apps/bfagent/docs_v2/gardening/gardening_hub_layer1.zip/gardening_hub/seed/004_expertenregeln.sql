-- =============================================================================
-- Gardening Hub: Expertenregeln
-- =============================================================================

-- REGELKATEGORIEN
INSERT INTO gh_regel_kategorien (code, name_de, beschreibung, prioritaet, ist_aktiv)
VALUES
    ('LICHT', 'Lichtbedarf', 'Regeln für Lichtanforderungen', 100, TRUE),
    ('WINTERHAERTE', 'Winterhärte', 'Regeln für Frostverträglichkeit', 90, TRUE),
    ('BODEN', 'Bodenanforderungen', 'Regeln für Bodentyp und pH-Wert', 80, TRUE),
    ('WASSER', 'Wasserbedarf', 'Regeln für Feuchtigkeit', 70, TRUE),
    ('NACHBARSCHAFT', 'Pflanzennachbarschaft', 'Regeln für gute/schlechte Nachbarn', 60, TRUE),
    ('ABSTAND', 'Pflanzabstand', 'Regeln für Mindestabstände', 50, TRUE);

-- EXPERTENREGELN
INSERT INTO gh_expertenregeln (
    code, kategorie_code, name_de, beschreibung,
    bedingung_json, aktion, meldung_template, gewicht, ist_aktiv
) VALUES

-- === LICHT-REGELN ===
('LICHT_MATCH_OPTIMAL', 'LICHT', 'Optimale Lichtverhältnisse',
 'Standort-Licht entspricht dem optimalen Lichtbedarf der Pflanze',
 '{"standort.licht": {"$eq": "pflanze.licht_optimal_code"}}',
 'empfehlen',
 '{pflanze.deutscher_name} ist ideal für diesen {standort.licht_name} Standort.',
 100, TRUE),

('LICHT_MATCH_TOLERANZ', 'LICHT', 'Akzeptable Lichtverhältnisse',
 'Standort-Licht liegt zwischen min und max Toleranz',
 '{"standort.licht": {"$between": ["pflanze.licht_min_code", "pflanze.licht_max_code"]}}',
 'empfehlen',
 '{pflanze.deutscher_name} toleriert diesen Standort, bevorzugt aber {pflanze.licht_optimal_name}.',
 80, TRUE),

('LICHT_ZU_DUNKEL', 'LICHT', 'Standort zu schattig',
 'Standort hat weniger Licht als die Pflanze minimal benötigt',
 '{"standort.licht": {"$lt": "pflanze.licht_min_code"}}',
 'warnen',
 '{pflanze.deutscher_name} benötigt mehr Licht. Standort ist zu schattig.',
 100, TRUE),

('LICHT_ZU_HELL', 'LICHT', 'Standort zu sonnig',
 'Standort hat mehr Sonne als die Pflanze verträgt',
 '{"standort.licht": {"$gt": "pflanze.licht_max_code"}}',
 'warnen',
 '{pflanze.deutscher_name} verträgt keine volle Sonne. Blattverbrennungen möglich.',
 100, TRUE),

-- === WINTERHÄRTE-REGELN ===
('WINTERHAERTE_OK', 'WINTERHAERTE', 'Winterhart am Standort',
 'Pflanze übersteht die minimalen Temperaturen am Standort',
 '{"pflanze.winterhaerte_zone": {"$lte": "standort.winterhaerte_zone"}}',
 'empfehlen',
 '{pflanze.deutscher_name} ist ausreichend winterhart für diesen Standort.',
 100, TRUE),

('WINTERHAERTE_GRENZWERTIG', 'WINTERHAERTE', 'Winterschutz empfohlen',
 'Pflanze ist nur knapp winterhart',
 '{"pflanze.winterhaerte_zone": {"$eq": "standort.winterhaerte_zone"}}',
 'warnen',
 '{pflanze.deutscher_name} ist grenzwertig winterhart. Winterschutz empfohlen.',
 90, TRUE),

('WINTERHAERTE_NICHT_OK', 'WINTERHAERTE', 'Nicht winterhart',
 'Pflanze übersteht den Winter nicht',
 '{"pflanze.winterhaerte_zone": {"$gt": "standort.winterhaerte_zone"}}',
 'ausschliessen',
 '{pflanze.deutscher_name} ist nicht winterhart genug für diesen Standort.',
 100, TRUE),

-- === BODEN-REGELN ===
('BODEN_MATCH', 'BODEN', 'Passender Bodentyp',
 'Standort-Boden entspricht den Anforderungen',
 '{"standort.boden_typ": {"$in": "pflanze.boden_typen_codes"}}',
 'empfehlen',
 '{pflanze.deutscher_name} gedeiht gut in {standort.boden_name}.',
 100, TRUE),

('BODEN_PH_OK', 'BODEN', 'pH-Wert passend',
 'Standort-pH liegt im Toleranzbereich',
 '{"standort.ph_wert": {"$between": ["pflanze.ph_min", "pflanze.ph_max"]}}',
 'empfehlen',
 'Der pH-Wert ist ideal für {pflanze.deutscher_name}.',
 90, TRUE),

('BODEN_PH_ZU_SAUER', 'BODEN', 'Boden zu sauer',
 'pH-Wert unter dem Minimum',
 '{"standort.ph_wert": {"$lt": "pflanze.ph_min"}}',
 'warnen',
 'Der Boden ist zu sauer für {pflanze.deutscher_name}. Kalken empfohlen.',
 80, TRUE),

-- === WASSER-REGELN ===
('TROCKENHEIT_OK', 'WASSER', 'Trockenheitsverträglich',
 'Pflanze verträgt trockenen Standort',
 '{"standort.ist_trocken": {"$eq": true}, "pflanze.trockenheitsvertraeglich": {"$eq": true}}',
 'empfehlen',
 '{pflanze.deutscher_name} ist ideal für trockene Standorte.',
 100, TRUE),

('TROCKENHEIT_NICHT_OK', 'WASSER', 'Nicht trockenheitsverträglich',
 'Pflanze benötigt mehr Wasser',
 '{"standort.ist_trocken": {"$eq": true}, "pflanze.trockenheitsvertraeglich": {"$eq": false}}',
 'warnen',
 '{pflanze.deutscher_name} benötigt regelmäßige Bewässerung an diesem Standort.',
 90, TRUE);
