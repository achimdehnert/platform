"""
Gardening Hub - Service für Pflanzen-Operationen.

Business Logic Layer zwischen API und Repository.
"""
from __future__ import annotations
from typing import Sequence, TYPE_CHECKING
from dataclasses import dataclass

from gardening_hub.models.pflanze import Pflanzenart, Standortanforderung
from gardening_hub.schemas.pflanze import PflanzenartCreate

if TYPE_CHECKING:
    from gardening_hub.unit_of_work.uow import UnitOfWork


@dataclass
class StandortFilter:
    """Filter-Kriterien für Standortsuche."""
    licht_code: str | None = None
    winterhaerte_zone_code: str | None = None
    boden_typ_code: str | None = None
    trockenheitsvertraeglich: bool | None = None
    ist_bienenfreundlich: bool | None = None
    ist_heimisch: bool | None = None
    ist_immergruen: bool | None = None
    ist_giftig: bool | None = None
    max_hoehe_cm: int | None = None
    min_hoehe_cm: int | None = None
    lebensform_code: str | None = None


class PflanzenService:
    """
    Service für Pflanzen-Operationen.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            service = PflanzenService(uow)
            pflanzen = await service.finde_passende_pflanzen(filter)
    """
    
    def __init__(self, uow: UnitOfWork):
        self._uow = uow
    
    # =========================================================================
    # LESEN
    # =========================================================================
    
    async def get_alle_pflanzen(
        self, 
        skip: int = 0, 
        limit: int = 100
    ) -> Sequence[Pflanzenart]:
        """Alle Pflanzen abrufen."""
        return await self._uow.pflanzen.get_alle_mit_standort(
            skip=skip, 
            limit=limit
        )
    
    async def get_pflanze_by_id(self, id: int) -> Pflanzenart | None:
        """Einzelne Pflanze per ID abrufen."""
        return await self._uow.pflanzen.get_by_id_mit_standort(id)
    
    async def get_pflanze_by_name(self, name: str) -> Pflanzenart | None:
        """Pflanze per botanischem Namen abrufen."""
        return await self._uow.pflanzen.get_by_botanischer_name(name)
    
    async def suche_pflanzen(
        self, 
        suchbegriff: str,
        limit: int = 20
    ) -> Sequence[Pflanzenart]:
        """Pflanzen nach Name suchen."""
        return await self._uow.pflanzen.suche_nach_name(suchbegriff, limit)
    
    # =========================================================================
    # FILTERN
    # =========================================================================
    
    async def finde_passende_pflanzen(
        self, 
        filter: StandortFilter
    ) -> Sequence[Pflanzenart]:
        """
        Pflanzen finden, die zu den Standortkriterien passen.
        
        Kombiniert Repository-Abfragen für komplexe Filter.
        """
        # Basis-Abfrage nach Standort
        pflanzen = await self._uow.pflanzen.get_by_standort(
            licht_code=filter.licht_code,
            winterhaerte_zone_code=filter.winterhaerte_zone_code,
            trockenheitsvertraeglich=filter.trockenheitsvertraeglich,
        )
        
        # Weitere Filter in-memory anwenden
        ergebnis = []
        for pflanze in pflanzen:
            if self._passt_zu_filter(pflanze, filter):
                ergebnis.append(pflanze)
        
        return ergebnis
    
    def _passt_zu_filter(
        self, 
        pflanze: Pflanzenart, 
        filter: StandortFilter
    ) -> bool:
        """Prüft ob Pflanze allen Filterkriterien entspricht."""
        # Eigenschaften
        if filter.ist_bienenfreundlich is not None:
            if pflanze.ist_bienenfreundlich != filter.ist_bienenfreundlich:
                return False
        
        if filter.ist_heimisch is not None:
            if pflanze.ist_heimisch != filter.ist_heimisch:
                return False
        
        if filter.ist_immergruen is not None:
            if pflanze.ist_immergruen != filter.ist_immergruen:
                return False
        
        if filter.ist_giftig is not None:
            if pflanze.ist_giftig != filter.ist_giftig:
                return False
        
        # Höhe
        if filter.max_hoehe_cm is not None:
            if pflanze.hoehe_max_cm and pflanze.hoehe_max_cm > filter.max_hoehe_cm:
                return False
        
        if filter.min_hoehe_cm is not None:
            if pflanze.hoehe_min_cm and pflanze.hoehe_min_cm < filter.min_hoehe_cm:
                return False
        
        # Lebensform
        if filter.lebensform_code is not None:
            if pflanze.lebensform_code != filter.lebensform_code:
                return False
        
        # Boden
        if filter.boden_typ_code is not None and pflanze.standort:
            boden_liste = pflanze.standort.boden_liste
            if boden_liste and filter.boden_typ_code not in boden_liste:
                return False
        
        return True
    
    async def get_bienenfreundliche_pflanzen(self) -> Sequence[Pflanzenart]:
        """Alle bienenfreundlichen Pflanzen abrufen."""
        return await self._uow.pflanzen.get_by_eigenschaften(
            ist_bienenfreundlich=True
        )
    
    async def get_heimische_pflanzen(self) -> Sequence[Pflanzenart]:
        """Alle heimischen Pflanzen abrufen."""
        return await self._uow.pflanzen.get_by_eigenschaften(
            ist_heimisch=True
        )
    
    async def get_ungiftige_pflanzen(self) -> Sequence[Pflanzenart]:
        """Alle ungiftigen Pflanzen abrufen (für Gärten mit Kindern)."""
        return await self._uow.pflanzen.get_by_eigenschaften(
            ist_giftig=False
        )
    
    # =========================================================================
    # ERSTELLEN / AKTUALISIEREN
    # =========================================================================
    
    async def erstelle_pflanze(
        self, 
        daten: PflanzenartCreate
    ) -> Pflanzenart:
        """Neue Pflanze erstellen."""
        pflanze = Pflanzenart(**daten.model_dump(exclude={'standort'}))
        
        if daten.standort:
            pflanze.standort = Standortanforderung(
                **daten.standort.model_dump()
            )
        
        pflanze = await self._uow.pflanzen.create(pflanze)
        await self._uow.commit()
        return pflanze
    
    async def aktualisiere_pflanze(
        self,
        id: int,
        **kwargs
    ) -> Pflanzenart | None:
        """Pflanze aktualisieren."""
        pflanze = await self._uow.pflanzen.get_by_id(id)
        if not pflanze:
            return None
        
        for key, value in kwargs.items():
            if hasattr(pflanze, key) and value is not None:
                setattr(pflanze, key, value)
        
        pflanze = await self._uow.pflanzen.update(pflanze)
        await self._uow.commit()
        return pflanze
    
    async def loesche_pflanze(self, id: int) -> bool:
        """Pflanze löschen."""
        erfolg = await self._uow.pflanzen.delete_by_id(id)
        if erfolg:
            await self._uow.commit()
        return erfolg
