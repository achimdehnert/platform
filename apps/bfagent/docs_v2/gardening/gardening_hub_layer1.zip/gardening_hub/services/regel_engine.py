"""
Gardening Hub - Regel-Engine für das Expertensystem.

Wertet datenbank-getriebene Regeln aus und bewertet Pflanzen
für einen gegebenen Standort.
"""
from __future__ import annotations
import json
from typing import Sequence, TYPE_CHECKING
from dataclasses import dataclass, field

from gardening_hub.models.pflanze import Pflanzenart
from gardening_hub.models.regeln import Expertenregel

if TYPE_CHECKING:
    from gardening_hub.unit_of_work.uow import UnitOfWork


@dataclass
class StandortKontext:
    """Kontext-Daten für einen Gartenstandort."""
    licht_code: str
    winterhaerte_zone_code: str
    boden_typ_code: str | None = None
    ph_wert: float | None = None
    ist_trocken: bool = False
    
    # Optionale Anzeigenamen für Meldungen
    licht_name: str | None = None
    boden_name: str | None = None


@dataclass
class RegelErgebnis:
    """Ergebnis einer einzelnen Regelauswertung."""
    regel_code: str
    regel_name: str
    kategorie: str
    aktion: str  # empfehlen, warnen, ausschliessen
    meldung: str
    gewicht: int


@dataclass
class PflanzenBewertung:
    """Gesamtbewertung einer Pflanze für einen Standort."""
    pflanze: Pflanzenart
    gesamt_score: int = 0
    ergebnisse: list[RegelErgebnis] = field(default_factory=list)
    empfohlen: bool = True
    warnungen: list[str] = field(default_factory=list)
    ausschluss_grund: str | None = None
    
    @property
    def hat_warnungen(self) -> bool:
        """Prüft ob Warnungen vorliegen."""
        return len(self.warnungen) > 0
    
    @property
    def anzahl_positive_regeln(self) -> int:
        """Anzahl positiv ausgewerteter Regeln."""
        return sum(1 for e in self.ergebnisse if e.aktion == 'empfehlen')


class RegelEngine:
    """
    Engine zur Auswertung von Expertenregeln.
    
    Verwendet datenbank-getriebene Regeln für maximale Flexibilität.
    Neue Regeln können per SQL hinzugefügt werden ohne Code-Deployment.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            engine = RegelEngine(uow)
            bewertungen = await engine.bewerte_pflanzen(standort, pflanzen)
    """
    
    # Licht-Reihenfolge für Vergleiche (niedrig = wenig Licht)
    LICHT_ORDNUNG = {
        'SCHATTEN': 1,
        'HALBSCHATTEN': 2,
        'TEILSONNE': 3,
        'VOLLE_SONNE': 4,
    }
    
    # Winterhärte-Reihenfolge (niedrig = kälter)
    WINTERHAERTE_ORDNUNG = {
        'ZONE_5A': 1, 'ZONE_5B': 2,
        'ZONE_6A': 3, 'ZONE_6B': 4,
        'ZONE_7A': 5, 'ZONE_7B': 6,
        'ZONE_8A': 7, 'ZONE_8B': 8,
    }
    
    def __init__(self, uow: UnitOfWork):
        self._uow = uow
        self._regeln: list[Expertenregel] = []
        self._regeln_geladen: bool = False
    
    async def lade_regeln(self) -> None:
        """Alle aktiven Regeln aus der Datenbank laden."""
        self._regeln = list(await self._uow.regeln.get_alle_aktiven())
        self._regeln_geladen = True
    
    async def bewerte_pflanzen(
        self,
        standort: StandortKontext,
        pflanzen: Sequence[Pflanzenart],
    ) -> list[PflanzenBewertung]:
        """
        Bewertet eine Liste von Pflanzen für einen Standort.
        
        Args:
            standort: Standortkontext mit Licht, Winterhärte, etc.
            pflanzen: Liste der zu bewertenden Pflanzen
            
        Returns:
            Liste von Bewertungen, sortiert nach Score (beste zuerst)
        """
        if not self._regeln_geladen:
            await self.lade_regeln()
        
        bewertungen = []
        for pflanze in pflanzen:
            bewertung = self._bewerte_pflanze(standort, pflanze)
            bewertungen.append(bewertung)
        
        # Sortieren: Empfohlene zuerst, dann nach Score absteigend
        bewertungen.sort(
            key=lambda b: (not b.empfohlen, -b.gesamt_score)
        )
        
        return bewertungen
    
    async def bewerte_einzelne_pflanze(
        self,
        standort: StandortKontext,
        pflanze: Pflanzenart,
    ) -> PflanzenBewertung:
        """Einzelne Pflanze für einen Standort bewerten."""
        if not self._regeln_geladen:
            await self.lade_regeln()
        
        return self._bewerte_pflanze(standort, pflanze)
    
    def _bewerte_pflanze(
        self,
        standort: StandortKontext,
        pflanze: Pflanzenart,
    ) -> PflanzenBewertung:
        """Interne Methode: Einzelne Pflanze bewerten."""
        bewertung = PflanzenBewertung(pflanze=pflanze)
        
        for regel in self._regeln:
            ergebnis = self._werte_regel_aus(standort, pflanze, regel)
            if ergebnis:
                bewertung.ergebnisse.append(ergebnis)
                
                if ergebnis.aktion == 'empfehlen':
                    bewertung.gesamt_score += ergebnis.gewicht
                elif ergebnis.aktion == 'warnen':
                    bewertung.warnungen.append(ergebnis.meldung)
                    bewertung.gesamt_score -= ergebnis.gewicht // 2
                elif ergebnis.aktion == 'ausschliessen':
                    bewertung.empfohlen = False
                    bewertung.ausschluss_grund = ergebnis.meldung
                    bewertung.gesamt_score = -1000
        
        return bewertung
    
    def _werte_regel_aus(
        self,
        standort: StandortKontext,
        pflanze: Pflanzenart,
        regel: Expertenregel,
    ) -> RegelErgebnis | None:
        """Einzelne Regel auswerten."""
        try:
            bedingung = json.loads(regel.bedingung_json)
        except json.JSONDecodeError:
            return None
        
        # Kontext für Auswertung aufbauen
        kontext = self._erstelle_kontext(standort, pflanze)
        
        # Bedingung prüfen
        if self._pruefe_bedingung(bedingung, kontext):
            meldung = self._formatiere_meldung(regel.meldung_template, kontext)
            return RegelErgebnis(
                regel_code=regel.code,
                regel_name=regel.name_de,
                kategorie=regel.kategorie_code,
                aktion=regel.aktion,
                meldung=meldung,
                gewicht=regel.gewicht,
            )
        
        return None
    
    def _erstelle_kontext(
        self,
        standort: StandortKontext,
        pflanze: Pflanzenart,
    ) -> dict:
        """Kontext-Dictionary für Regelauswertung erstellen."""
        kontext = {
            # Standort-Daten
            'standort.licht': standort.licht_code,
            'standort.licht_name': standort.licht_name or standort.licht_code,
            'standort.winterhaerte_zone': standort.winterhaerte_zone_code,
            'standort.boden_typ': standort.boden_typ_code,
            'standort.boden_name': standort.boden_name or standort.boden_typ_code,
            'standort.ph_wert': standort.ph_wert,
            'standort.ist_trocken': standort.ist_trocken,
            
            # Pflanzen-Stammdaten
            'pflanze.deutscher_name': pflanze.deutscher_name,
            'pflanze.botanischer_name': pflanze.botanischer_name,
            'pflanze.ist_giftig': pflanze.ist_giftig,
            'pflanze.ist_bienenfreundlich': pflanze.ist_bienenfreundlich,
            'pflanze.ist_heimisch': pflanze.ist_heimisch,
        }
        
        # Standortanforderungen der Pflanze
        if pflanze.standort:
            s = pflanze.standort
            kontext.update({
                'pflanze.licht_optimal_code': s.licht_optimal_code,
                'pflanze.licht_min_code': s.licht_min_code,
                'pflanze.licht_max_code': s.licht_max_code,
                'pflanze.winterhaerte_zone': s.winterhaerte_zone_code,
                'pflanze.boden_typen_codes': s.boden_typen_codes,
                'pflanze.ph_min': float(s.ph_min) if s.ph_min else None,
                'pflanze.ph_max': float(s.ph_max) if s.ph_max else None,
                'pflanze.trockenheitsvertraeglich': s.trockenheitsvertraeglich,
                'pflanze.staunaesse_vertraeglich': s.staunaesse_vertraeglich,
            })
            
            # Anzeigenamen für Licht (falls vorhanden)
            if s.licht_optimal:
                kontext['pflanze.licht_optimal_name'] = s.licht_optimal.name_de
        
        return kontext
    
    def _pruefe_bedingung(self, bedingung: dict, kontext: dict) -> bool:
        """Prüft ob alle Bedingungen erfüllt sind."""
        for feld, operator_dict in bedingung.items():
            wert = kontext.get(feld)
            
            for operator, vergleichswert in operator_dict.items():
                # Referenz auf anderes Feld auflösen
                if isinstance(vergleichswert, str) and vergleichswert in kontext:
                    vergleichswert = kontext[vergleichswert]
                
                if not self._pruefe_operator(
                    wert, operator, vergleichswert, kontext
                ):
                    return False
        
        return True
    
    def _pruefe_operator(
        self, 
        wert, 
        operator: str, 
        vergleichswert, 
        kontext: dict
    ) -> bool:
        """Einzelnen Operator prüfen."""
        if wert is None:
            return False
        
        if operator == '$eq':
            return wert == vergleichswert
        
        elif operator == '$neq':
            return wert != vergleichswert
        
        elif operator == '$lt':
            if isinstance(wert, str) and wert in self.LICHT_ORDNUNG:
                return self._vergleiche_licht(wert, vergleichswert) < 0
            return wert < vergleichswert
        
        elif operator == '$gt':
            if isinstance(wert, str) and wert in self.LICHT_ORDNUNG:
                return self._vergleiche_licht(wert, vergleichswert) > 0
            return wert > vergleichswert
        
        elif operator == '$lte':
            if isinstance(wert, str) and wert in self.LICHT_ORDNUNG:
                return self._vergleiche_licht(wert, vergleichswert) <= 0
            return wert <= vergleichswert
        
        elif operator == '$gte':
            if isinstance(wert, str) and wert in self.LICHT_ORDNUNG:
                return self._vergleiche_licht(wert, vergleichswert) >= 0
            return wert >= vergleichswert
        
        elif operator == '$in':
            if isinstance(vergleichswert, str):
                vergleichswert = [v.strip() for v in vergleichswert.split(',')]
            return wert in vergleichswert
        
        elif operator == '$between':
            min_val, max_val = vergleichswert
            # Referenzen auflösen
            if isinstance(min_val, str) and min_val in kontext:
                min_val = kontext[min_val]
            if isinstance(max_val, str) and max_val in kontext:
                max_val = kontext[max_val]
            
            if isinstance(wert, str) and wert in self.LICHT_ORDNUNG:
                return self._ist_zwischen_licht(wert, min_val, max_val)
            
            if min_val is None or max_val is None:
                return True
            return min_val <= wert <= max_val
        
        return False
    
    def _vergleiche_licht(self, wert1: str, wert2: str) -> int:
        """Vergleicht zwei Licht-Codes. Gibt <0, 0, >0 zurück."""
        if not wert1 or not wert2:
            return 0
        ord1 = self.LICHT_ORDNUNG.get(wert1, 0)
        ord2 = self.LICHT_ORDNUNG.get(wert2, 0)
        return ord1 - ord2
    
    def _ist_zwischen_licht(
        self, 
        wert: str, 
        min_val: str | None, 
        max_val: str | None
    ) -> bool:
        """Prüft ob Licht-Wert zwischen min und max liegt."""
        if not min_val or not max_val:
            return True
        ord_wert = self.LICHT_ORDNUNG.get(wert, 0)
        ord_min = self.LICHT_ORDNUNG.get(min_val, 0)
        ord_max = self.LICHT_ORDNUNG.get(max_val, 0)
        return ord_min <= ord_wert <= ord_max
    
    def _formatiere_meldung(
        self, 
        template: str | None, 
        kontext: dict
    ) -> str:
        """Meldungs-Template mit Kontext-Werten füllen."""
        if not template:
            return ""
        
        meldung = template
        for key, value in kontext.items():
            placeholder = '{' + key + '}'
            if placeholder in meldung:
                meldung = meldung.replace(
                    placeholder, 
                    str(value) if value is not None else ''
                )
        
        return meldung
