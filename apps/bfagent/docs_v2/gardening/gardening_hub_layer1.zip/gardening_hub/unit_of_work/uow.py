"""
Gardening Hub - Unit of Work Pattern.

Koordiniert Repositories und Transaktionen.
Async SQLAlchemy 2.0+ Implementierung.
"""
from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from gardening_hub.repositories import (
    LookupRepository,
    PflanzenRepository,
    CadRepository,
    RegelRepository,
)

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncEngine


class UnitOfWork:
    """
    Unit of Work - koordiniert Repositories und Transaktionen.
    
    Stellt sicher, dass alle Datenbankoperationen innerhalb einer
    Transaktion ausgeführt werden. Bei Fehlern wird automatisch
    ein Rollback durchgeführt.
    
    Verwendung:
        async with UnitOfWork(session_factory) as uow:
            pflanze = await uow.pflanzen.get_by_id(1)
            lookups = await uow.lookups.get_lichtbedarf_alle()
            
            # Änderungen speichern
            await uow.commit()
    
    Attributes:
        lookups: Repository für Lookup-Tabellen
        pflanzen: Repository für Pflanzenarten
        cad: Repository für CAD-Konfiguration
        regeln: Repository für Expertenregeln
    """
    
    lookups: LookupRepository
    pflanzen: PflanzenRepository
    cad: CadRepository
    regeln: RegelRepository
    
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]):
        """
        Initialisiert das Unit of Work.
        
        Args:
            session_factory: Async Session Factory von SQLAlchemy
        """
        self._session_factory = session_factory
        self._session: AsyncSession | None = None
    
    async def __aenter__(self) -> UnitOfWork:
        """Context Manager Entry - erstellt Session und Repositories."""
        self._session = self._session_factory()
        
        # Repositories initialisieren
        self.lookups = LookupRepository(self._session)
        self.pflanzen = PflanzenRepository(self._session)
        self.cad = CadRepository(self._session)
        self.regeln = RegelRepository(self._session)
        
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context Manager Exit - Rollback bei Fehler, Session schließen."""
        if exc_type is not None:
            await self.rollback()
        await self._session.close()
    
    async def commit(self) -> None:
        """
        Transaktion committen.
        
        Speichert alle Änderungen in der Datenbank.
        """
        await self._session.commit()
    
    async def rollback(self) -> None:
        """
        Transaktion zurückrollen.
        
        Verwirft alle nicht gespeicherten Änderungen.
        """
        await self._session.rollback()
    
    async def flush(self) -> None:
        """
        Änderungen in die Datenbank schreiben ohne Commit.
        
        Nützlich um IDs zu erhalten oder Constraints zu prüfen.
        """
        await self._session.flush()
    
    async def refresh(self, obj) -> None:
        """
        Objekt aus der Datenbank neu laden.
        
        Args:
            obj: Das zu aktualisierende SQLAlchemy-Objekt
        """
        await self._session.refresh(obj)
    
    @property
    def session(self) -> AsyncSession:
        """
        Direkter Session-Zugriff für komplexe Queries.
        
        Sollte nur verwendet werden, wenn die Repository-Methoden
        nicht ausreichen.
        """
        if self._session is None:
            raise RuntimeError(
                "Session nicht verfügbar. "
                "UnitOfWork muss als Context Manager verwendet werden."
            )
        return self._session


def create_unit_of_work_factory(
    engine: AsyncEngine
) -> async_sessionmaker[AsyncSession]:
    """
    Erstellt eine Session Factory für das Unit of Work.
    
    Args:
        engine: Async SQLAlchemy Engine
        
    Returns:
        Session Factory für UnitOfWork
        
    Verwendung:
        engine = create_async_engine(DATABASE_URL)
        session_factory = create_unit_of_work_factory(engine)
        
        async with UnitOfWork(session_factory) as uow:
            ...
    """
    return async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
